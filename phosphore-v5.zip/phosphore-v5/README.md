# Phosphore v5

3D wireframes traced like an XY oscilloscope on the Nothing Glyph Matrix.

## New in v5
- **Jetpack Compose + Material 3 UI.** The 700-line View-based activity is gone:
  - `MainActivity` (60 lines) only hosts Compose and binds the player service.
  - `ui/AppViewModel` owns settings state, undo, custom-shape operations.
  - `ui/screens/`: `MainScreen` plus one file per tab (`TraceTab`, `LookTab`, `MotionTab`,
    `ReactTab`, `OutputTab`) and `DrawScreen` (was a separate activity).
  - `ui/components/`: `Controls` (fader, toggle, segmented, cards, buttons) and
    `Display` (matrix preview, tiles, status pill, transport, LFO scope).
  - `ui/theme/`: colours and type scale.
- **Modern APIs**: Activity Result API instead of `startActivityForResult` /
  `onRequestPermissionsResult`; ViewModel + coroutines instead of raw threads;
  edge-to-edge via `enableEdgeToEdge`; vibration through `VibratorManager` with touch
  attributes instead of the deprecated haptic-setting lookup.
- **CRT power on/off**: switching the matrix off collapses the trace into a bright line,
  then a dot, then it fades, on the LEDs and the preview. Power-on plays it in reverse,
  timed to start once the matrix is actually connected. The Always-on toy uses it too.
- **Richer haptics** from vibration primitives: low ticks along sliders (firmer when
  moving fast), a thud at the ends, a soft click as a slider snaps magnetically onto its
  default, distinct on/off switch clicks, rising hum for power-on, falling for power-off.
- **Undo instead of dialogs**: presets, reset and deleting your own traces show a
  snackbar with Undo. Deleted traces sit in a trash folder until the snackbar goes away.
- **Accessibility**: sliders are real adjustable controls for TalkBack (label, spoken
  value, set-progress), switches/tabs/pickers have proper roles and selection states,
  tiles announce "Playing", the preview has Next/Previous actions, the status pill is a
  live region, text follows the system font size, and every text colour is ≥ 4.5:1.
