package com.adrienby.phosphore.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

/**
 * Colours. Every text colour is at least 4.5:1 against the surfaces it sits on
 * (Faint was 2.7:1 in v4). [Decor] is for non-text marks only.
 */
object Ph {
    val Bg = Color(0xFF182026)
    val Surface = Color(0xFF212B32)
    val SurfaceHi = Color(0xFF2A3640)
    val Rule = Color(0xFF34424D)
    val Screen = Color(0xFF0F1519)
    val Ink = Color(0xFFE4EAEE)        // 10–13:1
    val InkDim = Color(0xFFA6B8C4)     // ≥ 6:1
    val InkFaint = Color(0xFF8EA3AC)   // ≥ 4.7:1
    val Decor = Color(0xFF5F6E79)
    val Active = Color(0xFF62B4E2)     // ≥ 5.3:1
    val ActiveDim = Color(0xFF2C536A)
    val Live = Color(0xFF7ED9A0)
    val Warn = Color(0xFFE7B45A)
    val Danger = Color(0xFFE36F66)
    val LedOff = Color(0xFF1C252B)
    val LedOn = Color(0xFFF4F8FA)
}

object PhType {
    private val f = FontFamily.Default
    val title = TextStyle(fontFamily = f, fontWeight = FontWeight.Bold, fontSize = 22.sp)
    val nowPlaying = TextStyle(fontFamily = f, fontWeight = FontWeight.SemiBold, fontSize = 19.sp)
    val body = TextStyle(fontFamily = f, fontWeight = FontWeight.Normal, fontSize = 15.sp, lineHeight = 20.sp)
    val label = TextStyle(fontFamily = f, fontWeight = FontWeight.Normal, fontSize = 14.sp)
    val note = TextStyle(fontFamily = f, fontWeight = FontWeight.Normal, fontSize = 13.sp, lineHeight = 17.sp)
    val caption = TextStyle(fontFamily = f, fontWeight = FontWeight.SemiBold, fontSize = 12.sp, letterSpacing = 1.4.sp)
    val value = TextStyle(fontFamily = f, fontWeight = FontWeight.Medium, fontSize = 14.sp, fontFeatureSettings = "tnum")
    val control = TextStyle(fontFamily = f, fontWeight = FontWeight.Medium, fontSize = 13.5.sp)
    val button = TextStyle(fontFamily = f, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
    val tile = TextStyle(fontFamily = f, fontWeight = FontWeight.Medium, fontSize = 12.5.sp)
}

@Composable
fun PhosphoreTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Ph.Active, onPrimary = Ph.Screen,
            secondary = Ph.Active, onSecondary = Ph.Screen,
            background = Ph.Bg, onBackground = Ph.Ink,
            surface = Ph.Surface, onSurface = Ph.Ink,
            surfaceVariant = Ph.SurfaceHi, onSurfaceVariant = Ph.InkDim,
            inverseSurface = Ph.SurfaceHi, inverseOnSurface = Ph.Ink, inversePrimary = Ph.Active,
            error = Ph.Danger, outline = Ph.Rule,
        ),
        typography = Typography(bodyLarge = PhType.body, bodyMedium = PhType.label, labelLarge = PhType.button),
        content = content,
    )
}
