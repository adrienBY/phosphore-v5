package com.adrienby.phosphore.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.adrienby.phosphore.engine.ScopeSettings.Companion as K
import com.adrienby.phosphore.ui.AppViewModel
import com.adrienby.phosphore.ui.components.ChipButton
import com.adrienby.phosphore.ui.components.Fader
import com.adrienby.phosphore.ui.components.LfoScope
import com.adrienby.phosphore.ui.components.SectionCard
import com.adrienby.phosphore.ui.components.ToggleRow
import kotlin.math.pow
import kotlin.math.roundToInt

@Composable
fun LookTab(vm: AppViewModel) = TabPage {
    val s = vm.settings
    val d = vm.defaults

    SectionCard("Presets", "Sets the look. Your trace and output options stay; you can undo.") {
        LazyRow(Modifier.padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(K.PRESETS, key = { it.first }) { (name, preset) ->
                ChipButton(name) { vm.applyPreset(name, preset) }
            }
        }
    }

    SectionCard("Beam") {
        Fader("Sweep", s.sweep, d.sweep, { AppViewModel.formatHz(K.sweepHz(it)) }) { v -> vm.change { it.copy(sweep = v) } }
        Fader("Bandwidth", s.bandwidth, d.bandwidth, { "%d× sweep".format(K.bandwidthHarmonics(it).roundToInt()) }) { v ->
            vm.change { it.copy(bandwidth = v) }
        }
        Fader("Focus", s.focus, d.focus, { "%.2f LED".format(K.focusSigma(it)) }) { v -> vm.change { it.copy(focus = v) } }
    }

    SectionCard("Sweep oscillation",
        "Swings the sweep up and down around the Sweep knob, so the beam alternates between drawing the shape and holding it.") {
        ToggleRow("Oscillate", null, s.sweepLfo) { on -> vm.change { it.copy(sweepLfo = on) } }
        LfoScope(s.lfoShape, s.sweepLfo, vm.live.lfoPos, vm.live.lfoValue, vm.live.sweepText)
        Options("Waveform",
            listOf("Sine" to K.LFO_SINE, "Triangle" to K.LFO_TRIANGLE, "Pulse" to K.LFO_PULSE, "Drift" to K.LFO_DRIFT),
            s.lfoShape) { v -> vm.change { it.copy(lfoShape = v) } }
        Fader("Rate", s.lfoRate, d.lfoRate, {
            val p = K.lfoPeriod(it); if (p < 10f) "every %.1f s".format(p) else "every %d s".format(p.roundToInt())
        }) { v -> vm.change { it.copy(lfoRate = v) } }
        Fader("Depth", s.lfoDepth, d.lfoDepth, {
            val o = K.lfoOctaves(it)
            if (o < 0.05f) "none" else { val f = 2f.pow(o); "÷%.1f to ×%.1f".format(f, f) }
        }) { v -> vm.change { it.copy(lfoDepth = v) } }
    }

    SectionCard("Phosphor") {
        Fader("Persistence", s.persistence, d.persistence, {
            val sec = K.persistenceSec(it); if (sec < 1f) "%d ms".format((sec * 1000).roundToInt()) else "%.1f s".format(sec)
        }) { v -> vm.change { it.copy(persistence = v) } }
        Fader("Intensity", s.intensity, d.intensity, ::pct) { v -> vm.change { it.copy(intensity = v) } }
        Fader("Contrast", s.contrast, d.contrast, { "γ %.1f".format(K.gamma(it)) }) { v -> vm.change { it.copy(contrast = v) } }
        Fader("Depth shading", s.depth, d.depth, ::pct) { v -> vm.change { it.copy(depth = v) } }
        Fader("Noise", s.noise, d.noise, ::pct) { v -> vm.change { it.copy(noise = v) } }
        Fader("Breathing", s.breathing, d.breathing, ::pct) { v -> vm.change { it.copy(breathing = v) } }
    }
}
