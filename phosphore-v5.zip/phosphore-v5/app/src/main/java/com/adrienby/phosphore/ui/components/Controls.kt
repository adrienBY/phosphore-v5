package com.adrienby.phosphore.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.ProgressBarRangeInfo
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.progressBarRangeInfo
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.setProgress
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.adrienby.phosphore.ui.Haptics
import com.adrienby.phosphore.ui.theme.Ph
import com.adrienby.phosphore.ui.theme.PhType
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt

// ======================================================================= press feedback

@Composable
private fun pressedScale(source: MutableInteractionSource, scale: Float): Float {
    val pressed by source.collectIsPressedAsState()
    val s by animateFloatAsState(
        if (pressed) scale else 1f,
        spring(dampingRatio = 0.45f, stiffness = Spring.StiffnessMedium), label = "press",
    )
    return s
}

/** Springy scale-down while pressed; pass the same interaction source as the clickable. */
@Composable
fun Modifier.pressable(source: MutableInteractionSource, scale: Float = 0.95f): Modifier {
    val s = pressedScale(source, scale)
    return this.graphicsLayer { scaleX = s; scaleY = s }
}

// ======================================================================= card & text

@Composable
fun SectionCard(
    title: String?,
    subtitle: String? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(bottom = 12.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(Ph.Surface)
            .padding(horizontal = 18.dp, vertical = 16.dp)
    ) {
        if (title != null) Text(
            title.uppercase(), style = PhType.caption, color = Ph.InkDim,
            modifier = Modifier.semantics { heading() },
        )
        if (subtitle != null) Text(subtitle, style = PhType.note, color = Ph.InkFaint, modifier = Modifier.padding(top = 4.dp))
        content()
    }
}

@Composable
fun Note(text: String, color: Color = Ph.InkFaint, modifier: Modifier = Modifier) =
    Text(text, style = PhType.note, color = color, modifier = modifier.padding(top = 6.dp))

@Composable
fun FieldLabel(text: String) =
    Text(text, style = PhType.label, color = Ph.InkDim, modifier = Modifier.padding(top = 14.dp, bottom = 8.dp))

// ======================================================================= fader

private const val STEPS = 40

/**
 * Slider with label and value. Drag horizontally (vertical drags still scroll the page), tap to
 * jump, double-tap for the default. Textured with low ticks as it moves, a thud at either end,
 * and a soft click when it settles on the default (it snaps there magnetically).
 * Screen readers get a proper adjustable control: label, spoken value, and set-progress.
 */
@Composable
fun Fader(
    label: String,
    value: Float,
    default: Float,
    format: (Float) -> String,
    onChange: (Float) -> Unit,
) {
    val latestValue by rememberUpdatedState(value)
    val latestChange by rememberUpdatedState(onChange)
    var dragging by remember { mutableStateOf(false) }
    var lastStep by remember { mutableIntStateOf((value * STEPS).roundToInt()) }
    var lastX by remember { mutableStateOf(0f) }
    var lastT by remember { mutableStateOf(0L) }
    val shown = remember { Animatable(value) }
    LaunchedEffect(value) {
        if (dragging) shown.snapTo(value) else shown.animateTo(value, tween(260))
    }
    val press by animateFloatAsState(if (dragging) 1f else 0f, tween(160), label = "fader-press")
    val text = format(value)

    fun emit(v: Float, fromDrag: Boolean, speed: Float = 0f) {
        var t = v.coerceIn(0f, 1f)
        // magnetic default
        if (fromDrag && abs(t - default) < 0.012f) t = default
        val prev = latestValue
        if (fromDrag) {
            val s = (t * STEPS).roundToInt()
            when {
                t == default && prev != default -> Haptics.snap()
                s != lastStep && (t <= 0f || t >= 1f) -> Haptics.edge()
                s != lastStep -> Haptics.tick(speed)
            }
            lastStep = s
        } else lastStep = (t * STEPS).roundToInt()
        latestChange(t)
    }

    Column(
        Modifier
            .fillMaxWidth()
            .clearAndSetSemantics {
                contentDescription = label
                stateDescription = text
                progressBarRangeInfo = ProgressBarRangeInfo(value, 0f..1f, steps = 0)
                setProgress { target -> emit(target, fromDrag = false); true }
            }
    ) {
        Row(Modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(label, style = PhType.body, color = Ph.Ink, modifier = Modifier.weight(1f))
            Text(text, style = PhType.value, color = Ph.Active, textAlign = TextAlign.End)
        }
        Canvas(
            Modifier
                .fillMaxWidth()
                .height(36.dp)
                .pointerInput(Unit) {
                    val r = 12.dp.toPx()
                    detectTapGestures(
                        onTap = { o ->
                            Haptics.detent()
                            emit(((o.x - r) / (size.width - 2 * r)), fromDrag = false)
                        },
                        onDoubleTap = { Haptics.snap(); emit(default, fromDrag = false) },
                    )
                }
                .pointerInput(Unit) {
                    val r = 12.dp.toPx()
                    detectHorizontalDragGestures(
                        onDragStart = { o ->
                            dragging = true
                            Haptics.dragStart()
                            lastX = o.x; lastT = System.nanoTime()
                            emit((o.x - r) / (size.width - 2 * r), fromDrag = true)
                        },
                        onDragEnd = { dragging = false },
                        onDragCancel = { dragging = false },
                    ) { change, _ ->
                        change.consume()
                        val x = change.position.x
                        val now = System.nanoTime()
                        val dt = max(1L, now - lastT) / 1e9f
                        val speed = (abs(x - lastX) / size.width / dt / 3f).coerceIn(0f, 1f)
                        lastX = x; lastT = now
                        emit((x - r) / (size.width - 2 * r), fromDrag = true, speed = speed)
                    }
                }
        ) {
            val r = 12.dp.toPx()
            val th = 6.dp.toPx()
            val y = size.height / 2
            val left = r; val right = size.width - r
            val x = left + (right - left) * shown.value
            drawRoundRect(Ph.SurfaceHi, Offset(left, y - th / 2), Size(right - left, th), CornerRadius(th, th))
            drawRoundRect(Ph.Active, Offset(left, y - th / 2), Size(x - left, th), CornerRadius(th, th))
            drawCircle(Ph.Decor, 1.6.dp.toPx(), Offset(left + (right - left) * default, y + 10.dp.toPx()))
            if (press > 0f) drawCircle(Ph.Active.copy(alpha = 0.24f * press), r * (1.7f + 0.3f * press), Offset(x, y))
            drawCircle(Ph.Ink, (r - 2.dp.toPx()) * (1f + 0.15f * press), Offset(x, y))
        }
    }
}

// ======================================================================= toggle

@Composable
fun ToggleRow(
    title: String,
    subtitle: String? = null,
    checked: Boolean,
    onChange: (Boolean) -> Unit,
) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(top = 4.dp)
            .clip(RoundedCornerShape(12.dp))
            .toggleable(value = checked, role = Role.Switch) { on ->
                Haptics.toggle(on)
                onChange(on)
            }
            .padding(vertical = 10.dp, horizontal = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f).padding(end = 14.dp)) {
            Text(title, style = PhType.body, color = Ph.Ink)
            if (!subtitle.isNullOrEmpty()) Text(subtitle, style = PhType.note, color = Ph.InkFaint, modifier = Modifier.padding(top = 2.dp))
        }
        SwitchKnob(checked)
    }
}

@Composable
fun SwitchKnob(checked: Boolean) {
    val t by animateFloatAsState(
        if (checked) 1f else 0f, spring(dampingRatio = 0.62f, stiffness = 700f), label = "switch",
    )
    Canvas(Modifier.size(50.dp, 30.dp)) {
        val h = size.height; val w = size.width
        drawRoundRect(lerp(Ph.SurfaceHi, Ph.Active, t.coerceIn(0f, 1f)), cornerRadius = CornerRadius(h / 2, h / 2))
        val r = h / 2 - 4.dp.toPx()
        drawCircle(lerp(Ph.InkDim, Ph.Screen, t.coerceIn(0f, 1f)), r, Offset(h / 2 + (w - h) * t, h / 2))
    }
}

// ======================================================================= segmented

/** Pick-one control with a sliding pill. `tabs = true` gives the quieter tab-bar look. */
@Composable
fun Segmented(
    items: List<String>,
    selected: Int,
    onPick: (Int) -> Unit,
    tabs: Boolean = false,
    modifier: Modifier = Modifier,
) {
    val pos by animateFloatAsState(
        selected.toFloat(), spring(dampingRatio = 0.78f, stiffness = 520f), label = "seg",
    )
    val fontScale = LocalDensity.current.fontScale
    val height: Dp = (if (tabs) 46.dp else 40.dp) * max(1f, fontScale)
    val well = if (tabs) Ph.Surface else Ph.SurfaceHi
    val pill = if (tabs) Ph.SurfaceHi else Ph.Active
    BoxWithConstraints(
        modifier
            .fillMaxWidth()
            .height(height)
            .clip(RoundedCornerShape(50))
            .background(well)
    ) {
        val segW = maxWidth / items.size
        Box(
            Modifier
                .offset(x = segW * pos)
                .width(segW)
                .fillMaxHeight()
                .padding(3.dp)
                .clip(RoundedCornerShape(50))
                .background(pill)
        )
        Row(Modifier.fillMaxSize().selectableGroup()) {
            items.forEachIndexed { i, label ->
                val near = (1f - abs(pos - i)).coerceIn(0f, 1f)
                val color = if (tabs) lerp(Ph.InkDim, Ph.Active, near) else lerp(Ph.Ink, Ph.Screen, near)
                Box(
                    Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .selectable(
                            selected = i == selected,
                            role = if (tabs) Role.Tab else Role.RadioButton,
                        ) {
                            if (i != selected) { Haptics.detent(); onPick(i) }
                        },
                    contentAlignment = Alignment.Center,
                ) {
                    Text(label, style = PhType.control, color = color, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(horizontal = 4.dp))
                }
            }
        }
    }
}

// ======================================================================= buttons

@Composable
fun PrimaryButton(text: String, onClick: () -> Unit) {
    val src = remember { MutableInteractionSource() }
    Box(
        Modifier
            .fillMaxWidth()
            .padding(top = 14.dp)
            .pressable(src, 0.97f)
            .heightIn(min = 50.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(Ph.Active)
            .clickable(interactionSource = src, indication = androidx.compose.material3.ripple(), role = Role.Button) {
                Haptics.confirm(); onClick()
            },
        contentAlignment = Alignment.Center,
    ) { Text(text, style = PhType.button, color = Ph.Screen, modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) }
}

@Composable
fun GhostButton(text: String, color: Color = Ph.Ink, onClick: () -> Unit) {
    val src = remember { MutableInteractionSource() }
    Box(
        Modifier
            .fillMaxWidth()
            .padding(top = 12.dp)
            .pressable(src, 0.97f)
            .heightIn(min = 48.dp)
            .clip(RoundedCornerShape(14.dp))
            .border(1.dp, Ph.Rule, RoundedCornerShape(14.dp))
            .clickable(interactionSource = src, indication = androidx.compose.material3.ripple(), role = Role.Button) {
                Haptics.press(); onClick()
            },
        contentAlignment = Alignment.Center,
    ) { Text(text, style = PhType.button, color = color, modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) }
}

@Composable
fun ChipButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val src = remember { MutableInteractionSource() }
    Box(
        modifier
            .pressable(src, 0.94f)
            .heightIn(min = 40.dp)
            .clip(RoundedCornerShape(50))
            .background(Ph.SurfaceHi)
            .clickable(interactionSource = src, indication = androidx.compose.material3.ripple(), role = Role.Button) {
                Haptics.press(); onClick()
            },
        contentAlignment = Alignment.Center,
    ) { Text(text, style = PhType.control, color = Ph.Ink, modifier = Modifier.padding(horizontal = 16.dp, vertical = 9.dp)) }
}

@Composable
fun ChipRow(content: @Composable () -> Unit) {
    Row(
        Modifier.padding(top = 10.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) { content() }
}
