package com.adrienby.phosphore

import android.media.audiofx.Visualizer
import android.os.SystemClock
import kotlin.math.max
import kotlin.math.sqrt

/**
 * Listens to the phone's audio output mix (Visualizer on session 0) and reports a loudness
 * level 0..1 plus beat onsets. Needs the RECORD_AUDIO permission; some apps' audio (DRM,
 * certain players) may be excluded by the system, in which case it simply stays quiet.
 */
class BeatDetector(private val onLevel: (level: Float, beat: Boolean) -> Unit) {

    private var vis: Visualizer? = null
    private var avg = 0f
    private var peak = 0.05f
    private var lastBeat = 0L

    /** Returns null on success, or an error message. */
    fun start(): String? {
        if (vis != null) return null
        return try {
            val v = Visualizer(0)
            v.enabled = false
            val range = Visualizer.getCaptureSizeRange()
            v.captureSize = 512.coerceIn(range[0], range[1])
            v.scalingMode = Visualizer.SCALING_MODE_NORMALIZED
            v.setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                override fun onWaveFormDataCapture(vz: Visualizer?, wf: ByteArray?, rate: Int) {
                    if (wf != null) process(wf)
                }
                override fun onFftDataCapture(vz: Visualizer?, fft: ByteArray?, rate: Int) {}
            }, Visualizer.getMaxCaptureRate(), true, false)
            v.enabled = true
            vis = v
            null
        } catch (t: Throwable) {
            stop()
            t.message ?: t.javaClass.simpleName
        }
    }

    fun stop() {
        val v = vis ?: return
        vis = null
        try { v.enabled = false } catch (_: Throwable) { }
        try { v.release() } catch (_: Throwable) { }
    }

    private fun process(wf: ByteArray) {
        var sum = 0.0
        for (b in wf) { val x = ((b.toInt() and 0xFF) - 128) / 128.0; sum += x * x }
        val rms = sqrt(sum / wf.size).toFloat()
        avg += (rms - avg) * 0.08f
        peak = max(rms, peak * 0.996f).coerceAtLeast(0.02f)
        val level = (rms / peak).coerceIn(0f, 1f)
        val now = SystemClock.uptimeMillis()
        val beat = rms > avg * 1.35f && rms > 0.03f && now - lastBeat > 260
        if (beat) lastBeat = now
        onLevel(if (rms < 0.004f) 0f else level, beat)
    }
}
