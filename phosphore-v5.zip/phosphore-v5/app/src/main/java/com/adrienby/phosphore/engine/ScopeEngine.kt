package com.adrienby.phosphore.engine

import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

/**
 * XY-oscilloscope simulation on a tiny LED grid.
 *
 *  - The beam sweeps the shape's path at [scanHz] cycles per second (blanked between strokes).
 *  - Deflection goes through a 2nd-order low-pass (amplifier bandwidth): corners round off,
 *    ring a little, and glow brighter where the beam slows down.
 *  - Energy is splatted with a normalised gaussian (focus) into a phosphor buffer that decays
 *    exponentially (persistence).
 *  - Shape changes can morph: both paths are resampled to the same point count, aligned to
 *    the cheapest correspondence, and interpolated.
 *
 * Pure Kotlin (no Android), so it runs the same in the player, the toy and JVM tests.
 * Not thread-safe: call everything from one thread.
 */
class ScopeEngine(val size: Int = 13, val library: ShapeLibrary = ShapeLibrary(null)) {

    val cells = size * size
    val phosphor = FloatArray(cells)
    val mask = BooleanArray(cells)

    private val c = (size - 1) / 2f
    private val radius: Float

    // ---- parameters
    private var rotSpeed = 1f
    private var scanHz = 40f
    private var tau = 0.25f
    private var sigma = 0.6f
    private var omega = 300f
    private var gain = 1f
    private var noise = 0.1f
    private var depthCue = 0.5f
    private var autoCycle = 0f
    private var shuffle = false
    private var spinMode = ScopeSettings.SPIN_TUMBLE
    private var sizeMul = 1f
    private var gamma = 1.6f
    private var breathing = 0f
    private var brightness = 1f
    private var invert = false
    private var morphDur = 1f
    private var lfoOn = false
    private var lfoShape = 0
    private var lfoPeriod = 8f
    private var lfoOct = 0f
    private var lfoPhase = 0f
    private var driftA = 0f
    private var driftB = 0f
    /** Sweep frequency actually in use this frame (base × oscillation), for display. */
    var liveSweepHz = 40f
        private set
    /** Oscillator output (-1..1) and position in its cycle (0..1), for the UI. */
    var lfoValue = 0f
        private set
    val lfoPosition get() = lfoPhase
    private val outMap = IntArray(cells) { it }
    private var mapFlip = false
    private var mapRot = 0

    // ---- reactive inputs (set by the host)
    /** Fraction of the trace drawn at full brightness (battery while charging), or < 0 for off. */
    var fill = -1f
    /** Target spin multiplier (music); smoothed internally. */
    var spinBoost = 1f
    private var spinNow = 1f
    private var pulse = 0f
    private val holo = FloatArray(9)
    private var holoOn = false

    // ---- CRT power (1 = on, 0 = dark). Off: collapse to a line, then a dot, then fade.
    private var powerOn = true
    private var powerP = 1f
    private var crtX = 1f
    private var crtY = 1f
    private var crtE = 1f
    /** Fully off and the off-animation has finished. */
    val isDark: Boolean get() = !powerOn && powerP <= 0f

    // ---- shape state
    var current: Shape = library.shapes.first()
        private set
    private var appliedShapeId: String? = null
    private var dirty = true
    private var morphFrom: Shape? = null
    private var morphT = 0f
    private var needAlign = false
    private var morphShift = 0
    private var morphRev = false

    // ---- motion / beam state
    private var time = 0f
    private var cycleTimer = 0f
    private var phase = 0f
    private var ax = 0.45f; private var ay = 0.6f; private var az = 0f
    private var rax = 0f; private var ray = 0f; private var raz = 0f
    private var userYaw = 0f; private var userPitch = 0f
    private var velYaw = 0f; private var velPitch = 0f
    private var dragging = false
    private var bx = 0f; private var by = 0f; private var bvx = 0f; private var bvy = 0f
    private val rng = Random(7)

    private val path = BeamPath()
    private val tmpA = BeamPath()
    private val tmpB = BeamPath()
    private val ra = FloatArray(MORPH_N * 3); private val wa = FloatArray(MORPH_N)
    private val rb = FloatArray(MORPH_N * 3); private val wb = FloatArray(MORPH_N)
    private val rm = FloatArray(MORPH_N * 3); private val wm = FloatArray(MORPH_N)
    private val pt = FloatArray(3)

    private val lut = FloatArray(LUT_N) { exp(-it * LUT_MAX / LUT_N) }
    private val wbuf = FloatArray(49)
    private val m0 = FloatArray(9)
    private val m1 = FloatArray(9)
    private val mu = FloatArray(9)
    private val tmp9 = FloatArray(9)
    private val dm = FloatArray(9)

    init {
        val r2 = when (size) { 13 -> 42f; 25 -> 153f; else -> (size / 2f) * (size / 2f) }
        for (y in 0 until size) for (x in 0 until size) {
            val dx = x - c; val dy = y - c
            mask[y * size + x] = dx * dx + dy * dy <= r2
        }
        radius = sqrt(r2) - 0.55f
        bx = c; by = c
    }

    // ================================================================== control

    fun apply(s: ScopeSettings) {
        rotSpeed = ScopeSettings.rotationRadPerSec(s.rotation)
        scanHz = ScopeSettings.sweepHz(s.sweep)
        tau = ScopeSettings.persistenceSec(s.persistence)
        sigma = ScopeSettings.focusSigma(s.focus)
        omega = ScopeSettings.bandwidthOmega(s.bandwidth)
        gain = ScopeSettings.gain(s.intensity)
        noise = s.noise
        depthCue = s.depth
        autoCycle = s.autoCycle.toFloat()
        shuffle = s.shuffle
        spinMode = s.spinMode
        sizeMul = ScopeSettings.sizeMul(s.size)
        gamma = ScopeSettings.gamma(s.contrast)
        breathing = s.breathing
        brightness = s.brightness.coerceIn(0f, 1f)
        invert = s.invert
        morphDur = s.morphMs / 1000f
        lfoOn = s.sweepLfo && s.lfoDepth > 0.001f
        lfoShape = s.lfoShape
        lfoPeriod = ScopeSettings.lfoPeriod(s.lfoRate)
        lfoOct = ScopeSettings.lfoOctaves(s.lfoDepth)
        if (s.flipX != mapFlip || s.rotate != mapRot) buildOutMap(s.flipX, s.rotate)
        if (s.shapeId != appliedShapeId) {
            appliedShapeId = s.shapeId
            library.byId(s.shapeId)?.let { setShape(it) }
        }
    }

    /** Explicit pick from the UI: always takes effect, even if it's the saved shape. */
    fun select(id: String) {
        appliedShapeId = id
        library.byId(id)?.let { setShape(it) }
    }

    fun setShape(shape: Shape) {
        cycleTimer = 0f
        // Same shape again (e.g. settings + explicit pick arriving together): don't restart or cancel a morph.
        if (shape === current) return
        if (morphDur > 0f && path.n > 1 && shape !== current) {
            morphFrom = current
            morphT = 0f
            needAlign = true
        } else {
            morphFrom = null
            phase = 0f
        }
        current = shape
        dirty = true
    }

    fun nextShape() = cycle(+1)
    fun previousShape() = cycle(-1)

    private fun cycle(dir: Int) {
        val list = library.shapes
        if (list.isEmpty()) return
        val i = list.indexOfFirst { it.id == current.id }.coerceAtLeast(0)
        val next = if (shuffle && list.size > 1) {
            var r = rng.nextInt(list.size - 1)
            if (r >= i) r++
            r
        } else Math.floorMod(i + dir, list.size)
        setShape(list[next])
    }

    /** Library changed (custom shape added/removed): keep the current shape if it still exists. */
    fun libraryChanged() {
        val again = library.byId(current.id)
        if (again == null) setShape(library.shapes.first()) else if (again !== current) { current = again; dirty = true }
    }

    fun drag(dYaw: Float, dPitch: Float, dt: Float) {
        dragging = true
        userYaw += dYaw; userPitch += dPitch
        if (dt > 0f) {
            velYaw = velYaw * 0.5f + 0.5f * dYaw / dt
            velPitch = velPitch * 0.5f + 0.5f * dPitch / dt
        }
    }

    fun release() { dragging = false }

    /** Turn the beam on/off with the CRT animation, or instantly. */
    fun power(on: Boolean, instant: Boolean = false) {
        powerOn = on
        if (instant) powerP = if (on) 1f else 0f
    }

    /** A flash of beam energy (notification, beat). */
    fun kick(amount: Float) { pulse = max(pulse, amount.coerceIn(0f, 1.5f)) }

    /** Extra rotation applied on top of everything, in screen space (steady-hologram mode). */
    fun setHologram(m: FloatArray?) {
        if (m == null) { holoOn = false; return }
        System.arraycopy(m, 0, holo, 0, 9)
        holoOn = true
    }

    fun clear() { phosphor.fill(0f) }

    // ================================================================== simulation

    fun step(dtIn: Float) {
        val dt = dtIn.coerceIn(0f, 0.1f)
        if (dt <= 0f) return
        time += dt

        if (autoCycle > 0f) {
            cycleTimer += dt
            if (cycleTimer >= autoCycle) nextShape()
        }
        rebuildPath(dt)

        val decay = exp(-dt / tau)
        for (i in 0 until cells) phosphor[i] *= decay
        pulse *= exp(-dt / 0.28f)
        powerP = (powerP + if (powerOn) dt / POWER_ON_S else -dt / POWER_OFF_S).coerceIn(0f, 1f)
        if (powerP <= 0f) return                 // dark: the phosphor just fades
        crt(powerP)
        spinNow += (spinBoost - spinNow) * min(1f, dt * 5f)

        // rotation at frame start / end, interpolated per sample (honest motion smear)
        val spins = current.spins && spinMode != ScopeSettings.SPIN_STILL
        autoAngles(current.spins)
        rotation(rax, ray, raz, userYaw, userPitch, m0)
        if (spins) {
            val w = rotSpeed * spinNow * dt
            if (spinMode == ScopeSettings.SPIN_TURNTABLE) ay += w
            else { ax += w * 0.62f; ay += w; az += w * 0.23f }
        }
        if (!dragging) {
            userYaw += velYaw * dt; userPitch += velPitch * dt
            val damp = exp(-dt * 2.2f)
            velYaw *= damp; velPitch *= damp
        }
        autoAngles(current.spins)
        rotation(rax, ray, raz, userYaw, userPitch, m1)
        if (holoOn) { premul(holo, m0); premul(holo, m1) }

        val sz = sizeMul * (1f + 0.10f * pulse)
        val screenLen = path.total * radius * sz
        val spc = (screenLen * 3.2f).coerceIn(160f, 4000f)
        lfoValue = if (lfoOn) lfo(dt) else 0f
        val hz = if (lfoOn) (scanHz * pow2(lfoOct * lfoValue)).coerceIn(0.05f, 2400f) else scanHz
        liveSweepHz = hz
        val cycles = hz * dt
        val ideal = cycles * spc
        val cap = min(BUDGET_PER_SEC * dt, 2f * spc)
        val n: Int
        val dPhase: Float
        if (ideal <= cap) { n = max(1, ideal.roundToInt()); dPhase = cycles / n }
        else { n = max(1, cap.toInt()); dPhase = 1f / spc }

        val breathe = if (breathing > 0f) 1f - breathing * 0.7f * (0.5f - 0.5f * cos(time * 1.6f)) else 1f
        val e = gain * breathe * crtE * (1f + 1.8f * pulse) * screenLen * dt / n

        // Exact discretisation of the deflection amplifier for one sample step (target held
        // constant over the step): error relative to the target evolves as x' = Φ x.
        val wd = omega * WD_K
        val decayH = exp(-ZETA * omega * dPhase)
        val cw = cos(wd * dPhase); val sw = sin(wd * dPhase)
        val f11 = decayH * (cw + ZETA * omega / wd * sw)
        val f12 = decayH * sw / wd
        val f21 = -decayH * omega * omega / wd * sw
        val f22 = decayH * (cw - ZETA * omega / wd * sw)
        val inv2s2 = 1f / (2f * sigma * sigma)
        val sr = min(3, ceil(2.4f * sigma).toInt())
        val scale = radius * (PERSP - 1f) * sz
        val jit = noise * 0.22f
        val hum = noise * 0.30f
        val fillOn = fill >= 0f

        for (j in 0 until 9) { dm[j] = (m1[j] - m0[j]) / n; mu[j] = m0[j] - 0.5f * dm[j] }
        var seg = path.locate(phase * path.total)
        for (k in 0 until n) {
            phase += dPhase
            if (phase >= 1f) { phase -= 1f; seg = 0 }
            val s = phase * path.total
            seg = path.advance(seg, s)
            val beam = path.point(seg, s, pt, 0)
            val px = pt[0]; val py = pt[1]; val pz = pt[2]

            for (j in 0 until 9) mu[j] += dm[j]
            val rx = mu[0] * px + mu[1] * py + mu[2] * pz
            val ry = mu[3] * px + mu[4] * py + mu[5] * pz
            val rz = mu[6] * px + mu[7] * py + mu[8] * pz

            val pk = scale / (PERSP - rz)
            var tx = c + rx * pk * crtX
            var ty = c - ry * pk * crtY
            if (noise > 0f) {
                val tReal = time - dt + dt * (k + 0.5f) / n
                tx += (rng.nextFloat() - 0.5f) * jit + hum * sin(tReal * 314.159f) * 0.5f
                ty += (rng.nextFloat() - 0.5f) * jit + hum * sin(tReal * 3.7f + 1f) * 0.3f
            }
            val ex = bx - tx; val ey = by - ty
            bx = tx + f11 * ex + f12 * bvx; bvx = f21 * ex + f22 * bvx
            by = ty + f11 * ey + f12 * bvy; bvy = f21 * ey + f22 * bvy
            if (beam > 0.01f) {
                var en = e * beam * (1f - depthCue * 0.75f * (0.5f - 0.5f * rz.coerceIn(-1f, 1f)))
                if (fillOn && phase > fill) en *= 0.1f
                if (noise > 0f) en *= 1f + (rng.nextFloat() - 0.5f) * noise * 0.6f
                splat(bx, by, en, inv2s2, sr)
            }
        }
    }

    /** Screen-space squash + energy for a power level p (1 = on). */
    private fun crt(p: Float) {
        fun ss(x: Float): Float { val k = x.coerceIn(0f, 1f); return k * k * (3f - 2f * k) }
        when {
            p >= 0.55f -> { crtX = 1f; crtY = max(0.012f, ss((p - 0.55f) / 0.45f)); crtE = 1f }
            p >= 0.30f -> { crtY = 0.012f; crtX = max(0.012f, ss((p - 0.30f) / 0.25f)); crtE = 1f }
            else -> { crtX = 0.012f; crtY = 0.012f; crtE = ss((p - 0.04f) / 0.26f) }
        }
    }

    /** Oscillator in -1..1, advanced by dt. */
    private fun lfo(dt: Float): Float {
        lfoPhase += dt / lfoPeriod
        if (lfoPhase >= 1f) {
            lfoPhase -= kotlin.math.floor(lfoPhase)
            driftA = driftB
            driftB = rng.nextFloat() * 2f - 1f
        }
        val p = lfoPhase
        return when (lfoShape) {
            ScopeSettings.LFO_TRIANGLE -> 1f - 4f * kotlin.math.abs(((p + 0.25f) % 1f) - 0.5f)
            ScopeSettings.LFO_PULSE -> kotlin.math.tanh(3.5f * sin(TAU * p)) / TANH35
            ScopeSettings.LFO_DRIFT -> { val k = 0.5f - 0.5f * cos(PI_F * p); driftA + (driftB - driftA) * k }
            else -> sin(TAU * p)
        }
    }

    private fun pow2(x: Float) = exp(x * LN2)

    private fun rebuildPath(dt: Float) {
        val from = morphFrom
        if (from == null) {
            if (dirty || current.animated) { path.fromStrokes(current.strokes(time)); dirty = false }
            return
        }
        tmpA.fromStrokes(from.strokes(time)); tmpA.resample(MORPH_N, ra, wa)
        tmpB.fromStrokes(current.strokes(time)); tmpB.resample(MORPH_N, rb, wb)
        if (needAlign) { align(); needAlign = false }
        val t = morphT.coerceIn(0f, 1f)
        val k = t * t * (3f - 2f * t)
        for (i in 0 until MORPH_N) {
            val j = mapIndex(i)
            val i3 = i * 3; val j3 = j * 3
            rm[i3] = ra[i3] + (rb[j3] - ra[i3]) * k
            rm[i3 + 1] = ra[i3 + 1] + (rb[j3 + 1] - ra[i3 + 1]) * k
            rm[i3 + 2] = ra[i3 + 2] + (rb[j3 + 2] - ra[i3 + 2]) * k
            wm[i] = wa[i] + (wb[j] - wa[i]) * k
        }
        path.fromLoop(rm, wm, MORPH_N)
        morphT += dt / morphDur.coerceAtLeast(0.05f)
        if (morphT >= 1f) { morphFrom = null; dirty = true; phase = 0f }
    }

    private fun mapIndex(i: Int) =
        if (morphRev) Math.floorMod(morphShift - i, MORPH_N) else (i + morphShift) % MORPH_N

    /** Picks the cyclic shift / direction that moves the points the least. */
    private fun align() {
        var best = Float.MAX_VALUE
        for (rev in booleanArrayOf(false, true)) {
            var shift = 0
            while (shift < MORPH_N) {
                var cost = 0f
                var i = 0
                while (i < MORPH_N) {
                    val j = if (rev) Math.floorMod(shift - i, MORPH_N) else (i + shift) % MORPH_N
                    val dx = ra[i * 3] - rb[j * 3]; val dy = ra[i * 3 + 1] - rb[j * 3 + 1]; val dz = ra[i * 3 + 2] - rb[j * 3 + 2]
                    cost += dx * dx + dy * dy + dz * dz
                    i += 4
                }
                if (cost < best) { best = cost; morphShift = shift; morphRev = rev }
                shift += 4
            }
        }
    }

    // ================================================================== output

    /** LED drive levels 0..1, exactly what the matrix shows (gamma, invert, brightness, orientation). */
    fun levels(out: FloatArray) {
        val k = 1.15f / tau
        for (i in 0 until cells) {
            out[i] = if (mask[i]) {
                var v = (1f - exp(-phosphor[outMap[i]] * k)).pow(gamma)
                if (invert) v = 1f - v
                v * brightness
            } else 0f
        }
    }

    /** Frame for the Glyph Matrix SDK: 0..4095 per LED, row-major. */
    fun toLed(out: IntArray, scratch: FloatArray) {
        levels(scratch)
        toLed(scratch, out)
    }

    // ================================================================== internals

    private fun buildOutMap(flip: Boolean, rot: Int) {
        mapFlip = flip; mapRot = rot
        val last = size - 1
        for (y in 0 until size) for (x in 0 until size) {
            var sx = x; var sy = y
            when (rot) {
                90 -> { sx = y; sy = last - x }
                180 -> { sx = last - x; sy = last - y }
                270 -> { sx = last - y; sy = x }
            }
            if (flip) sx = last - sx
            outMap[y * size + x] = sy * size + sx
        }
    }

    private fun autoAngles(spins: Boolean) {
        when {
            !spins -> { rax = 0f; ray = 0f; raz = 0f }
            spinMode == ScopeSettings.SPIN_TURNTABLE -> { rax = 0.38f; ray = ay; raz = 0f }
            else -> { rax = ax; ray = ay; raz = az }
        }
    }

    /** m = h * m */
    private fun premul(h: FloatArray, m: FloatArray) {
        for (r in 0..2) for (col in 0..2)
            tmp9[r * 3 + col] = h[r * 3] * m[col] + h[r * 3 + 1] * m[3 + col] + h[r * 3 + 2] * m[6 + col]
        System.arraycopy(tmp9, 0, m, 0, 9)
    }

    private fun splat(x: Float, y: Float, e: Float, inv2s2: Float, r: Int) {
        val cx = x.roundToInt(); val cy = y.roundToInt()
        var sum = 0f
        var idx = 0
        for (j in -r..r) for (i in -r..r) {
            val dx = cx + i - x; val dy = cy + j - y
            val a = (dx * dx + dy * dy) * inv2s2
            val w = if (a >= LUT_MAX) 0f else lut[(a * (LUT_N / LUT_MAX)).toInt()]
            wbuf[idx++] = w; sum += w
        }
        if (sum <= 1e-6f) return
        val norm = e / sum
        idx = 0
        for (j in -r..r) {
            val gy = cy + j
            for (i in -r..r) {
                val gx = cx + i
                val w = wbuf[idx++]
                if (gx in 0 until size && gy in 0 until size) phosphor[gy * size + gx] += w * norm
            }
        }
    }

    private fun rotation(ax: Float, ay: Float, az: Float, uy: Float, up: Float, m: FloatArray) {
        val cxr = cos(ax); val sxr = sin(ax)
        val cyr = cos(ay); val syr = sin(ay)
        val czr = cos(az); val szr = sin(az)
        val a00 = czr * cyr; val a01 = czr * syr * sxr - szr * cxr; val a02 = czr * syr * cxr + szr * sxr
        val a10 = szr * cyr; val a11 = szr * syr * sxr + czr * cxr; val a12 = szr * syr * cxr - czr * sxr
        val a20 = -syr;      val a21 = cyr * sxr;                    val a22 = cyr * cxr
        val cu = cos(uy); val su = sin(uy); val cp = cos(up); val sp = sin(up)
        val u00 = cu;        val u01 = 0f;  val u02 = su
        val u10 = sp * su;   val u11 = cp;  val u12 = -sp * cu
        val u20 = -cp * su;  val u21 = sp;  val u22 = cp * cu
        m[0] = u00 * a00 + u01 * a10 + u02 * a20
        m[1] = u00 * a01 + u01 * a11 + u02 * a21
        m[2] = u00 * a02 + u01 * a12 + u02 * a22
        m[3] = u10 * a00 + u11 * a10 + u12 * a20
        m[4] = u10 * a01 + u11 * a11 + u12 * a21
        m[5] = u10 * a02 + u11 * a12 + u12 * a22
        m[6] = u20 * a00 + u21 * a10 + u22 * a20
        m[7] = u20 * a01 + u21 * a11 + u22 * a21
        m[8] = u20 * a02 + u21 * a12 + u22 * a22
    }

    companion object {
        /** Converts [levels] output to SDK drive values without recomputing the frame. */
        fun toLed(levels: FloatArray, out: IntArray) {
            for (i in out.indices) out[i] = (levels[i] * 4095f).roundToInt().coerceIn(0, 4095)
        }

        /** Physical LED layout (13×13 → 137 LEDs, 25×25 → 489). */
        fun maskFor(size: Int): BooleanArray {
            val c = (size - 1) / 2f
            val r2 = when (size) { 13 -> 42f; 25 -> 153f; else -> (size / 2f) * (size / 2f) }
            return BooleanArray(size * size) { val dx = it % size - c; val dy = it / size - c; dx * dx + dy * dy <= r2 }
        }

        private const val TAU = 6.2831855f
        private const val PI_F = 3.1415927f
        private const val LN2 = 0.6931472f
        private val TANH35 = kotlin.math.tanh(3.5f)
        private val WD_K = sqrt(1f - ZETA_C * ZETA_C)
        private const val ZETA_C = 0.62f
        private const val LUT_N = 1024
        private const val LUT_MAX = 9f
        private const val ZETA = ZETA_C
        private const val PERSP = 4.0f
        private const val BUDGET_PER_SEC = 200_000f
        private const val MORPH_N = 512
        private const val POWER_ON_S = 0.6f
        private const val POWER_OFF_S = 0.65f
    }
}
