package com.adrienby.phosphore.ui.screens

import android.Manifest
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.adrienby.phosphore.ui.AppViewModel
import com.adrienby.phosphore.ui.Haptics
import com.adrienby.phosphore.ui.UiEvent
import com.adrienby.phosphore.ui.components.ICON_NEXT
import com.adrienby.phosphore.ui.components.ICON_POWER
import com.adrienby.phosphore.ui.components.ICON_PREV
import com.adrienby.phosphore.ui.components.MatrixPreview
import com.adrienby.phosphore.ui.components.Segmented
import com.adrienby.phosphore.ui.components.StatusPill
import com.adrienby.phosphore.ui.components.TransportButton
import com.adrienby.phosphore.ui.theme.Ph
import com.adrienby.phosphore.ui.theme.PhType
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.min

private val TABS = listOf("Trace", "Look", "Motion", "React", "Output")

@Composable
fun MainScreen(vm: AppViewModel) {
    val ctx = LocalContext.current
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    var notifDialog by remember { mutableStateOf(false) }

    // Frame pump: pull one frame from the player per display refresh.
    val player = vm.player
    LaunchedEffect(player) {
        if (player == null) return@LaunchedEffect
        while (isActive) { withFrameNanos { }; vm.poll() }
    }

    // Snackbars: every undoable action shows "Undo" for a few seconds.
    LaunchedEffect(Unit) {
        vm.events.collect { ev ->
            scope.launch {
                snackbar.currentSnackbarData?.dismiss()
                when (ev) {
                    is UiEvent.Undoable -> {
                        val r = snackbar.showSnackbar(ev.message, actionLabel = "Undo", duration = SnackbarDuration.Short)
                        if (r == SnackbarResult.ActionPerformed) { Haptics.press(); ev.undo() } else ev.dismissed()
                    }
                    is UiEvent.Message -> snackbar.showSnackbar(ev.text, duration = SnackbarDuration.Short)
                }
            }
        }
    }

    val notifPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    val audioPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        vm.player?.refreshBeat()
        if (!granted) vm.message("Without audio access the music mode can't listen")
    }
    val openObj = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importObj(uri)
    }
    fun askNotificationsIfNeeded() {
        if (ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    LaunchedEffect(Unit) { if (vm.settings.background) askNotificationsIfNeeded() }

    if (vm.drawing) {
        DrawScreen(
            onSave = { strokes, mode -> vm.saveDrawing(strokes, mode); vm.drawing = false },
            onClose = { vm.drawing = false },
        )
        return
    }

    Scaffold(
        containerColor = Ph.Bg,
        snackbarHost = {
            SnackbarHost(snackbar) { data ->
                Snackbar(data, shape = RoundedCornerShape(14.dp), containerColor = Ph.SurfaceHi, contentColor = Ph.Ink, actionColor = Ph.Active)
            }
        },
    ) { pad ->
        Column(Modifier.fillMaxSize().padding(pad)) {
            Header(vm)
            Stage(vm)
            NowPlaying(vm)
            Segmented(
                TABS, vm.settings.tab, { i -> vm.setTab(i) }, tabs = true,
                modifier = Modifier.padding(start = 16.dp, end = 16.dp, bottom = 6.dp),
            )
            AnimatedContent(
                targetState = vm.settings.tab,
                transitionSpec = {
                    (fadeIn(tween(220)) + slideInVertically(tween(260)) { it / 30 }) togetherWith fadeOut(tween(110))
                },
                label = "tabs",
                modifier = Modifier.weight(1f),
            ) { tab ->
                when (tab) {
                    0 -> TraceTab(vm, onDraw = { Haptics.press(); vm.drawing = true }, onImport = { openObj.launch(arrayOf("*/*")) })
                    1 -> LookTab(vm)
                    2 -> MotionTab(vm)
                    3 -> ReactTab(vm,
                        onNotifAccess = { notifDialog = true },
                        onNeedAudio = {
                            if (ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
                                audioPermission.launch(Manifest.permission.RECORD_AUDIO)
                        })
                    else -> OutputTab(vm, onToySettings = { openToySettings(ctx, vm.n) }, onBackgroundOn = { askNotificationsIfNeeded() })
                }
            }
        }
    }

    if (notifDialog) {
        AlertDialog(
            onDismissRequest = { notifDialog = false },
            containerColor = Ph.Surface,
            title = { Text("Notification access", color = Ph.Ink) },
            text = {
                Text(
                    "Phosphore only needs to know that a notification arrived, to flash the beam. It doesn't read or keep their content.\n\n" +
                        "On the next screen, enable Phosphore. If Android says it's a restricted setting: open Settings › Apps › Phosphore, " +
                        "tap ⋮ in the top corner, choose \"Allow restricted settings\", then come back and try again.",
                    color = Ph.InkDim, style = PhType.note,
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    notifDialog = false
                    try { ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) } catch (_: Throwable) { }
                }) { Text("Open settings", color = Ph.Active) }
            },
            dismissButton = { TextButton(onClick = { notifDialog = false }) { Text("Not now", color = Ph.InkDim) } },
        )
    }
}

@Composable
private fun Header(vm: AppViewModel) {
    Row(
        Modifier.fillMaxWidth().padding(start = 20.dp, end = 16.dp, top = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text("Phosphore", style = PhType.title, color = Ph.Ink, modifier = Modifier.semantics { heading() })
        Text("v5", style = PhType.caption, color = Ph.Active, modifier = Modifier.padding(start = 8.dp, top = 4.dp))
        Spacer(Modifier.weight(1f))
        StatusPill(vm.live.glyphState)
    }
}

@Composable
private fun Stage(vm: AppViewModel) {
    val conf = LocalConfiguration.current
    val side = min(236, (conf.screenHeightDp * 0.27f).toInt()).dp
    val on = vm.settings.mirror
    // the "off" hint fades in after the CRT power-off animation has played out
    val hint by animateFloatAsState(if (on) 0f else 1f, tween(400, delayMillis = if (on) 0 else 650), label = "off-hint")
    val name = vm.shapeName(vm.live.shapeId)
    Box(Modifier.fillMaxWidth().height(side + 16.dp), contentAlignment = Alignment.Center) {
        MatrixPreview(
            n = vm.n, mask = vm.mask, levels = vm.levels, frame = vm.live.frame,
            description = if (on) "Glyph Matrix preview: $name" else "Glyph Matrix preview: off",
            onDrag = { y, p, dt -> vm.player?.drag(y, p, dt) },
            onRelease = { vm.player?.release() },
            onNext = { vm.next() }, onPrevious = { vm.previous() },
            modifier = Modifier.size(side),
        )
        if (hint > 0.01f) Text("Off", style = PhType.caption, color = Ph.InkFaint, modifier = Modifier.alpha(hint))
    }
}

@Composable
private fun NowPlaying(vm: AppViewModel) {
    Row(
        Modifier.fillMaxWidth().padding(start = 20.dp, end = 16.dp, bottom = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Column(Modifier.weight(1f)) {
            Text(vm.shapeName(vm.live.shapeId), style = PhType.nowPlaying, color = Ph.Ink, maxLines = 1)
            Text("sweep ${vm.live.sweepText}", style = PhType.value, color = Ph.InkFaint)
        }
        TransportButton(ICON_PREV, "Previous trace") { vm.previous() }
        TransportButton(ICON_POWER, "Glyph Matrix", active = vm.settings.mirror, big = true) { vm.setPower(!vm.settings.mirror) }
        TransportButton(ICON_NEXT, "Next trace") { vm.next() }
        Spacer(Modifier.width(0.dp))
    }
}

private fun openToySettings(ctx: android.content.Context, n: Int) {
    if (n == 25) {
        try {
            ctx.startActivity(Intent().setComponent(ComponentName(
                "com.nothing.thirdparty", "com.nothing.thirdparty.matrix.toys.manager.ToysManagerActivity")))
            return
        } catch (_: Throwable) { }
    }
    try { ctx.startActivity(Intent(Settings.ACTION_SETTINGS)) } catch (_: Throwable) { }
    android.widget.Toast.makeText(ctx, "Glyph Interface › Flip to Glyph › Always-on Glyph Toy", android.widget.Toast.LENGTH_LONG).show()
}
