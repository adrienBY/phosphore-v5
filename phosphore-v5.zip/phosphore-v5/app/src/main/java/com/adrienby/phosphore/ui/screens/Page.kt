package com.adrienby.phosphore.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.adrienby.phosphore.ui.components.FieldLabel
import com.adrienby.phosphore.ui.components.Segmented
import kotlin.math.roundToInt

/** Scrolling column every tab lives in. */
@Composable
fun TabPage(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(start = 14.dp, end = 14.dp, top = 8.dp, bottom = 28.dp),
        content = content,
    )
}

/** Labelled pick-one row bound to an Int setting. */
@Composable
fun Options(label: String?, items: List<Pair<String, Int>>, current: Int, onPick: (Int) -> Unit) {
    if (label != null) FieldLabel(label)
    Segmented(
        items = items.map { it.first },
        selected = items.indexOfFirst { it.second == current }.coerceAtLeast(0),
        onPick = { i -> onPick(items[i].second) },
        modifier = if (label == null) Modifier.padding(top = 10.dp) else Modifier,
    )
}

fun pct(v: Float) = "%d%%".format((v * 100).roundToInt())
