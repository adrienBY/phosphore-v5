package com.adrienby.phosphore.engine

import java.util.Calendar
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * A shape is a list of strokes. Each stroke is a polyline of xyz triplets that the beam
 * draws without lifting; between strokes the beam is blanked (z-axis modulation).
 */
interface Shape {
    /** Stable identifier saved in settings. Built-ins use their name; custom ones "custom:<file>". */
    val id: String get() = name
    val name: String
    val category: String
    val animated: Boolean get() = false
    /** false = always faces the viewer (e.g. the clock); only manual drag rotates it. */
    val spins: Boolean get() = true
    fun strokes(t: Float): List<FloatArray>
}

private class StaticShape(
    override val name: String,
    override val category: String,
    private val data: List<FloatArray>,
) : Shape {
    override fun strokes(t: Float) = data
}

object Shapes {

    const val SOLIDS = "Solids"
    const val CURVES = "Curves"
    const val ANIMATED = "Animated"
    const val CUSTOM = "Yours"
    val CATEGORIES = listOf(SOLIDS, CURVES, ANIMATED)

    private const val TAU = (2.0 * PI).toFloat()
    private val PHI = ((1.0 + sqrt(5.0)) / 2.0).toFloat()

    val all: List<Shape> by lazy {
        listOf(
            // ---------------------------------------------------------------- solids
            StaticShape("Cube", SOLIDS, polyhedron(cubeVerts())),
            StaticShape("Tetrahedron", SOLIDS, polyhedron(listOf(
                v(1f, 1f, 1f), v(1f, -1f, -1f), v(-1f, 1f, -1f), v(-1f, -1f, 1f)))),
            StaticShape("Octahedron", SOLIDS, polyhedron(listOf(
                v(1f, 0f, 0f), v(-1f, 0f, 0f), v(0f, 1f, 0f),
                v(0f, -1f, 0f), v(0f, 0f, 1f), v(0f, 0f, -1f)))),
            StaticShape("Icosahedron", SOLIDS, polyhedron(icosaVerts())),
            StaticShape("Dodecahedron", SOLIDS, polyhedron(dodecaVerts())),
            StaticShape("Cuboctahedron", SOLIDS, polyhedron(cuboctaVerts())),
            StaticShape("Stella octangula", SOLIDS, stella()),
            StaticShape("Pyramid", SOLIDS, wire(
                listOf(v(-1f, -0.7f, -1f), v(1f, -0.7f, -1f), v(1f, -0.7f, 1f), v(-1f, -0.7f, 1f), v(0f, 1.1f, 0f)),
                listOf(e(0, 1), e(1, 2), e(2, 3), e(3, 0), e(0, 4), e(1, 4), e(2, 4), e(3, 4)))),
            StaticShape("Hex prism", SOLIDS, hexPrism()),
            // ---------------------------------------------------------------- curves
            StaticShape("Trefoil", CURVES, normalize(listOf(curve(420, true) { t ->
                val r = 2f + cos(3f * t)
                v(r * cos(2f * t), r * sin(2f * t), 1.2f * sin(3f * t))
            }))),
            StaticShape("Coil", CURVES, normalize(listOf(curve(720, true) { t ->
                val n = 13f; val rr = 0.36f
                val r = 1f + rr * cos(n * t)
                v(r * cos(t), r * sin(t), rr * sin(n * t))
            }))),
            StaticShape("Torus", CURVES, torus()),
            StaticShape("Globe", CURVES, normalize(listOf(curve(520, false) { t ->
                val p = t / 2f
                val k = 18f
                v(sin(p) * cos(k * p), cos(p), sin(p) * sin(k * p))
            }))),
            StaticShape("Gyroscope", CURVES, gyroscope()),
            StaticShape("Atom", CURVES, atom()),
            StaticShape("Seam", CURVES, normalize(listOf(curve(400, true) { t ->
                val a = 0.68f; val b = 0.32f
                v(a * cos(t) + b * cos(3f * t), a * sin(t) - b * sin(3f * t), 2f * sqrt(a * b) * sin(2f * t))
            }))),
            StaticShape("Lissajous", CURVES, normalize(listOf(curve(640, true) { t ->
                v(sin(3f * t + 0.5f * PI.toFloat()), sin(4f * t), sin(5f * t + 0.3f))
            }))),
            StaticShape("Spirograph", CURVES, normalize(listOf(curve(900, true, 3f * TAU) { t ->
                val big = 5f; val r = 3f; val d = 4.2f
                v((big - r) * cos(t) + d * cos((big - r) / r * t),
                  (big - r) * sin(t) - d * sin((big - r) / r * t),
                  1.6f * sin(5f * t / 3f))
            }))),
            StaticShape("Möbius", CURVES, mobius()),
            StaticShape("DNA", CURVES, dna()),
            StaticShape("Heart", CURVES, normalize(listOf(curve(300, true) { t ->
                val s = sin(t)
                v(16f * s * s * s, 13f * cos(t) - 5f * cos(2f * t) - 2f * cos(3f * t) - cos(4f * t), 4f * sin(2f * t))
            }))),
            StaticShape("Lorenz", CURVES, normalize(listOf(lorenz()))),
            // ---------------------------------------------------------------- animated
            Tesseract,
            Wave,
            Clock,
        )
    }

    fun byId(id: String) = all.firstOrNull { it.id == id }

    // ------------------------------------------------------------------ helpers

    private fun v(x: Float, y: Float, z: Float) = floatArrayOf(x, y, z)
    private fun e(a: Int, b: Int) = intArrayOf(a, b)

    /** Samples t over [0, tMax]. Closed curves repeat their first point so the beam never jumps. */
    private inline fun curve(n: Int, closed: Boolean, tMax: Float = TAU, f: (Float) -> FloatArray): FloatArray {
        val out = FloatArray((n + 1) * 3)
        for (i in 0..n) {
            val t = if (closed && i == n) 0f else tMax * i / n
            val p = f(t)
            out[i * 3] = p[0]; out[i * 3 + 1] = p[1]; out[i * 3 + 2] = p[2]
        }
        return out
    }

    private fun circle(n: Int, f: (Float) -> FloatArray) = curve(n, true, TAU, f)

    fun normalize(strokes: List<FloatArray>): List<FloatArray> {
        // centre on the bounding box so lopsided curves (heart, spirograph) sit in the middle
        val lo = DoubleArray(3) { Double.MAX_VALUE }; val hi = DoubleArray(3) { -Double.MAX_VALUE }
        for (s in strokes) for (i in s.indices) {
            val k = i % 3
            if (s[i] < lo[k]) lo[k] = s[i].toDouble()
            if (s[i] > hi[k]) hi[k] = s[i].toDouble()
        }
        val cx = (lo[0] + hi[0]) / 2; val cy = (lo[1] + hi[1]) / 2; val cz = (lo[2] + hi[2]) / 2
        var maxR = 1e-6f
        for (s in strokes) for (i in s.indices step 3) {
            val dx = s[i] - cx; val dy = s[i + 1] - cy; val dz = s[i + 2] - cz
            maxR = maxOf(maxR, sqrt((dx * dx + dy * dy + dz * dz).toFloat()))
        }
        return strokes.map { s ->
            FloatArray(s.size) { i ->
                val c = when (i % 3) { 0 -> cx; 1 -> cy; else -> cz }
                ((s[i] - c) / maxR).toFloat()
            }
        }
    }

    /** Edges = vertex pairs at the minimum distance (true for the Platonic and Archimedean solids used). */
    private fun polyhedron(verts: List<FloatArray>): List<FloatArray> {
        var minD = Float.MAX_VALUE
        for (i in verts.indices) for (j in i + 1 until verts.size) minD = minOf(minD, dist(verts[i], verts[j]))
        val edges = ArrayList<IntArray>()
        for (i in verts.indices) for (j in i + 1 until verts.size)
            if (dist(verts[i], verts[j]) < minD * 1.01f) edges.add(intArrayOf(i, j))
        return wire(verts, edges)
    }

    private fun wire(verts: List<FloatArray>, edges: List<IntArray>): List<FloatArray> {
        val paths = chainEdges(verts.size, edges)
        return normalize(paths.map { path -> FloatArray(path.size * 3) { verts[path[it / 3]][it % 3] } })
    }

    /** Greedy trail decomposition: fewer strokes = fewer beam blanks = a more continuous trace. */
    fun chainEdges(vertexCount: Int, edges: List<IntArray>): List<IntArray> {
        val used = BooleanArray(edges.size)
        val adj = Array(vertexCount) { ArrayList<Int>() }
        edges.forEachIndexed { i, e -> adj[e[0]].add(i); adj[e[1]].add(i) }
        fun deg(n: Int) = adj[n].count { !used[it] }
        val out = ArrayList<IntArray>()
        while (used.any { !it }) {
            val start = (0 until vertexCount).firstOrNull { deg(it) % 2 == 1 }
                ?: (0 until vertexCount).first { deg(it) > 0 }
            val path = arrayListOf(start)
            var cur = start
            while (true) {
                val ei = adj[cur].firstOrNull { !used[it] } ?: break
                used[ei] = true
                val ed = edges[ei]
                cur = if (ed[0] == cur) ed[1] else ed[0]
                path.add(cur)
            }
            out.add(path.toIntArray())
        }
        return out
    }

    private fun dist(a: FloatArray, b: FloatArray): Float {
        val dx = a[0] - b[0]; val dy = a[1] - b[1]; val dz = a[2] - b[2]
        return sqrt(dx * dx + dy * dy + dz * dz)
    }

    private fun cubeVerts(): List<FloatArray> {
        val l = ArrayList<FloatArray>()
        for (x in -1..1 step 2) for (y in -1..1 step 2) for (z in -1..1 step 2) l.add(v(x.toFloat(), y.toFloat(), z.toFloat()))
        return l
    }

    private fun icosaVerts(): List<FloatArray> {
        val l = ArrayList<FloatArray>()
        for (a in floatArrayOf(-1f, 1f)) for (b in floatArrayOf(-PHI, PHI)) {
            l.add(v(0f, a, b)); l.add(v(a, b, 0f)); l.add(v(b, 0f, a))
        }
        return l
    }

    private fun dodecaVerts(): List<FloatArray> {
        val l = ArrayList(cubeVerts())
        val ip = 1f / PHI
        for (a in floatArrayOf(-ip, ip)) for (b in floatArrayOf(-PHI, PHI)) {
            l.add(v(0f, a, b)); l.add(v(a, b, 0f)); l.add(v(b, 0f, a))
        }
        return l
    }

    private fun cuboctaVerts(): List<FloatArray> {
        val l = ArrayList<FloatArray>()
        for (a in floatArrayOf(-1f, 1f)) for (b in floatArrayOf(-1f, 1f)) {
            l.add(v(a, b, 0f)); l.add(v(a, 0f, b)); l.add(v(0f, a, b))
        }
        return l
    }

    /** Two interpenetrating tetrahedra on the cube's alternate corners. */
    private fun stella(): List<FloatArray> {
        val c = cubeVerts()
        val even = c.indices.filter { i -> c[i].count { it > 0 } % 2 == 0 }
        val odd = c.indices.filter { it !in even }
        val edges = ArrayList<IntArray>()
        for (group in listOf(even, odd)) for (i in group.indices) for (j in i + 1 until group.size) edges.add(e(group[i], group[j]))
        return wire(c, edges)
    }

    private fun hexPrism(): List<FloatArray> {
        val verts = ArrayList<FloatArray>()
        for (h in floatArrayOf(-0.75f, 0.75f)) for (k in 0 until 6) {
            val a = TAU * k / 6f
            verts.add(v(cos(a), h, sin(a)))
        }
        val edges = ArrayList<IntArray>()
        for (k in 0 until 6) {
            edges.add(e(k, (k + 1) % 6)); edges.add(e(6 + k, 6 + (k + 1) % 6)); edges.add(e(k, 6 + k))
        }
        return wire(verts, edges)
    }

    private fun torus(): List<FloatArray> {
        val big = 0.7f; val r = 0.3f
        val strokes = ArrayList<FloatArray>()
        for (k in 0 until 8) {
            val a = TAU * k / 8f
            strokes.add(circle(28) { t -> val rr = big + r * cos(t); v(rr * cos(a), r * sin(t), rr * sin(a)) })
        }
        for (rr in floatArrayOf(big + r, big - r)) strokes.add(circle(56) { t -> v(rr * cos(t), 0f, rr * sin(t)) })
        return normalize(strokes)
    }

    private fun gyroscope(): List<FloatArray> = normalize(listOf(
        circle(64) { t -> v(cos(t), sin(t), 0f) },
        circle(64) { t -> v(cos(t), 0f, sin(t)) },
        circle(64) { t -> v(0f, cos(t), sin(t)) },
    ))

    private fun atom(): List<FloatArray> {
        val strokes = ArrayList<FloatArray>()
        for (k in 0 until 3) {
            val tilt = PI.toFloat() / 3f * k
            strokes.add(circle(72) { t ->
                val x = cos(t); val y = 0.38f * sin(t)
                v(x * cos(tilt) - y * sin(tilt), x * sin(tilt) + y * cos(tilt), 0.38f * sin(t) * 0.6f)
            })
        }
        strokes.add(circle(14) { t -> v(0.1f * cos(t), 0.1f * sin(t), 0f) })
        return normalize(strokes)
    }

    private fun mobius(): List<FloatArray> {
        val w = 0.42f
        fun p(u: Float, s: Float): FloatArray {
            val r = 1f + s * cos(u / 2f)
            return v(r * cos(u), s * sin(u / 2f), r * sin(u))
        }
        val strokes = ArrayList<FloatArray>()
        strokes.add(curve(240, true, 2f * TAU) { u -> p(u, w) })   // its single edge
        for (k in 0 until 10) {
            val u = TAU * k / 10f
            strokes.add(floatArrayOf(*p(u, -w), *p(u, w)))
        }
        return normalize(strokes)
    }

    private fun dna(): List<FloatArray> {
        val turns = 1.6f
        fun helix(off: Float) = curve(160, false) { t ->
            val y = t / TAU * 2f - 1f
            val a = t * turns + off
            v(0.45f * cos(a), y, 0.45f * sin(a))
        }
        val strokes = arrayListOf(helix(0f), helix(PI.toFloat()))
        for (k in 1 until 10) {
            val t = TAU * k / 10f
            val y = t / TAU * 2f - 1f
            val a = t * turns
            strokes.add(floatArrayOf(0.45f * cos(a), y, 0.45f * sin(a), -0.45f * cos(a), y, -0.45f * sin(a)))
        }
        return normalize(strokes)
    }

    private fun lorenz(): FloatArray {
        var x = 0.1; var y = 0.0; var z = 0.0
        val s = 10.0; val r = 28.0; val b = 8.0 / 3.0; val dt = 0.008
        repeat(600) { val dx = s * (y - x); val dy = x * (r - z) - y; val dz = x * y - b * z; x += dx * dt; y += dy * dt; z += dz * dt }
        val n = 1100
        val out = FloatArray(n * 3)
        for (i in 0 until n) {
            val dx = s * (y - x); val dy = x * (r - z) - y; val dz = x * y - b * z
            x += dx * dt; y += dy * dt; z += dz * dt
            out[i * 3] = x.toFloat(); out[i * 3 + 1] = (z - 25.0).toFloat(); out[i * 3 + 2] = y.toFloat()
        }
        return out
    }

    // ------------------------------------------------------------------ animated

    /** 4D hypercube, double-rotated in the XW and ZW planes, perspective-projected into 3D. */
    private object Tesseract : Shape {
        override val name = "Tesseract"
        override val category = ANIMATED
        override val animated = true
        private val verts4 = Array(16) { i -> FloatArray(4) { k -> if (i shr k and 1 == 1) 1f else -1f } }
        private val paths: List<IntArray>
        private val buffers: List<FloatArray>
        private var norm = 1f
        private val p = Array(16) { FloatArray(3) }

        init {
            val edges = ArrayList<IntArray>()
            for (i in 0 until 16) for (k in 0 until 4) { val j = i xor (1 shl k); if (j > i) edges.add(intArrayOf(i, j)) }
            paths = chainEdges(16, edges)
            buffers = paths.map { FloatArray(it.size * 3) }
            var maxR = 1e-3f
            var t = 0f
            while (t < 120f) {
                for (b in strokes(t)) for (i in b.indices step 3)
                    maxR = maxOf(maxR, sqrt(b[i] * b[i] + b[i + 1] * b[i + 1] + b[i + 2] * b[i + 2]))
                t += 0.05f
            }
            norm = 1f / maxR
        }

        override fun strokes(t: Float): List<FloatArray> {
            val a = t * 0.55f; val b = t * 0.31f
            val ca = cos(a); val sa = sin(a); val cb = cos(b); val sb = sin(b)
            val dw = 3.2f
            for (i in 0 until 16) {
                val q = verts4[i]
                val x1 = q[0] * ca - q[3] * sa; val w1 = q[0] * sa + q[3] * ca
                val z1 = q[2] * cb - w1 * sb;   val w2 = q[2] * sb + w1 * cb
                val k = dw / (dw - w2) * norm
                p[i][0] = x1 * k; p[i][1] = q[1] * k; p[i][2] = z1 * k
            }
            for ((pi, path) in paths.withIndex()) {
                val buf = buffers[pi]
                for (j in path.indices) { val s = p[path[j]]; buf[j * 3] = s[0]; buf[j * 3 + 1] = s[1]; buf[j * 3 + 2] = s[2] }
            }
            return buffers
        }
    }

    /** A rippling surface, drawn as a boustrophedon raster in both directions. */
    private object Wave : Shape {
        override val name = "Wave"
        override val category = ANIMATED
        override val animated = true
        private const val LINES = 6
        private const val PTS = 22
        private val rows = FloatArray(LINES * PTS * 3)
        private val cols = FloatArray(LINES * PTS * 3)
        private val out = listOf(rows, cols)

        private fun h(x: Float, z: Float, t: Float): Float {
            val r = sqrt(x * x + z * z)
            return 0.28f * sin(5f * r - 3.2f * t) * exp(-0.9f * r) + 0.06f * sin(2f * x + t)
        }

        override fun strokes(t: Float): List<FloatArray> {
            val s = 0.7f
            var k = 0
            for (l in 0 until LINES) {
                val a = -1f + 2f * l / (LINES - 1)
                for (j in 0 until PTS) {
                    val jj = if (l % 2 == 0) j else PTS - 1 - j
                    val b = -1f + 2f * jj / (PTS - 1)
                    rows[k] = b * s; rows[k + 1] = h(b, a, t); rows[k + 2] = a * s
                    cols[k] = a * s; cols[k + 1] = h(a, b, t); cols[k + 2] = b * s
                    k += 3
                }
            }
            return out
        }
    }

    /** The classic oscilloscope clock: face, hour + minute hands in one stroke, a second tick. */
    private object Clock : Shape {
        override val name = "Clock"
        override val category = ANIMATED
        override val animated = true
        override val spins = false
        private val face = curve(72, true) { t -> v(0.95f * cos(t), 0.95f * sin(t), 0f) }
        private val hands = FloatArray(5 * 3)
        private val tick = FloatArray(2 * 3)
        private val out = listOf(face, hands, tick)
        private val cal: Calendar = Calendar.getInstance()

        override fun strokes(t: Float): List<FloatArray> {
            cal.timeInMillis = System.currentTimeMillis()
            val sec = cal.get(Calendar.SECOND) + cal.get(Calendar.MILLISECOND) / 1000f
            val min = cal.get(Calendar.MINUTE) + sec / 60f
            val hr = cal.get(Calendar.HOUR) + min / 60f
            fun ang(frac: Float) = PI.toFloat() / 2f - TAU * frac      // 12 o'clock = up
            val ah = ang(hr / 12f); val am = ang(min / 60f); val asec = ang(sec / 60f)
            // centre -> hour tip -> centre -> minute tip -> centre
            val pts = floatArrayOf(0f, 0f, 0.5f * cos(ah), 0.5f * sin(ah), 0f, 0f, 0.8f * cos(am), 0.8f * sin(am), 0f, 0f)
            for (i in 0 until 5) { hands[i * 3] = pts[i * 2]; hands[i * 3 + 1] = pts[i * 2 + 1]; hands[i * 3 + 2] = 0f }
            tick[0] = 0.95f * cos(asec); tick[1] = 0.95f * sin(asec); tick[2] = 0f
            tick[3] = 0.72f * cos(asec); tick[4] = 0.72f * sin(asec); tick[5] = 0f
            return out
        }
    }
}
