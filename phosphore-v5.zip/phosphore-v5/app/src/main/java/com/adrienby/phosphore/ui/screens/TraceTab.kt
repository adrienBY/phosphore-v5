package com.adrienby.phosphore.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.adrienby.phosphore.engine.Shape
import com.adrienby.phosphore.engine.Shapes
import com.adrienby.phosphore.ui.AppViewModel
import com.adrienby.phosphore.ui.components.SectionCard
import com.adrienby.phosphore.ui.components.ShapeTile
import com.adrienby.phosphore.ui.components.TILE_DRAW
import com.adrienby.phosphore.ui.components.TILE_IMPORT
import com.adrienby.phosphore.ui.components.TILE_SHAPE
import com.adrienby.phosphore.ui.components.ToggleRow

@Composable
fun TraceTab(vm: AppViewModel, onDraw: () -> Unit, onImport: () -> Unit) = TabPage {
    val s = vm.settings
    for (cat in Shapes.CATEGORIES) {
        SectionCard(cat) { TileRow(vm, vm.shapes.filter { it.category == cat }) }
    }
    SectionCard("Yours", "Draw your own or import a 3D model (.obj). Long-press one to delete it.") {
        TileRow(vm, vm.shapes.filter { it.category == Shapes.CUSTOM }, onDraw, onImport)
    }
    SectionCard("Changing traces") {
        Options("Transition", listOf("Cut" to 0, "0.5 s" to 500, "1 s" to 1000, "2 s" to 2000, "4 s" to 4000), s.morphMs) { v ->
            vm.change { it.copy(morphMs = v) }
        }
        Options("Change automatically", listOf("Off" to 0, "10 s" to 10, "30 s" to 30, "1 min" to 60, "5 min" to 300), s.autoCycle) { v ->
            vm.change { it.copy(autoCycle = v) }
        }
        ToggleRow("Shuffle", "Pick the next trace at random", s.shuffle) { on -> vm.change { it.copy(shuffle = on) } }
    }
}

@Composable
private fun TileRow(vm: AppViewModel, shapes: List<Shape>, onDraw: (() -> Unit)? = null, onImport: (() -> Unit)? = null) {
    val current = vm.live.shapeId
    LazyRow(Modifier.padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(shapes, key = { it.id }) { shape ->
            val custom = shape.category == Shapes.CUSTOM
            ShapeTile(
                name = shape.name, kind = TILE_SHAPE, isSelected = shape.id == current,
                n = vm.n, mask = vm.mask, thumb = vm.thumbs[shape.id],
                onClick = { vm.selectShape(shape.id) },
                onLongClick = if (custom) ({ vm.deleteCustom(shape.id) }) else null,
            )
        }
        if (onDraw != null) item(key = "add-draw") {
            ShapeTile("Draw", TILE_DRAW, false, vm.n, vm.mask, null, onClick = onDraw)
        }
        if (onImport != null) item(key = "add-import") {
            ShapeTile("Import .obj", TILE_IMPORT, false, vm.n, vm.mask, null, onClick = onImport)
        }
    }
}
