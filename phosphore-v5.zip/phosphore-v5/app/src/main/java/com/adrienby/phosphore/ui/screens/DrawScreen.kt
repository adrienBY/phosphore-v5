package com.adrienby.phosphore.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.adrienby.phosphore.engine.CustomShapes
import com.adrienby.phosphore.ui.Haptics
import com.adrienby.phosphore.ui.components.ChipButton
import com.adrienby.phosphore.ui.components.GhostButton
import com.adrienby.phosphore.ui.components.Note
import com.adrienby.phosphore.ui.components.PrimaryButton
import com.adrienby.phosphore.ui.components.Segmented
import com.adrienby.phosphore.ui.theme.Ph
import com.adrienby.phosphore.ui.theme.PhType
import kotlin.math.hypot

private val MODES = listOf("Lathe" to CustomShapes.LATHE, "Extrude" to CustomShapes.EXTRUDE, "Flat" to CustomShapes.FLAT)

/** Finger-drawn traces: Lathe spins a profile, Extrude gives depth, Flat stays as drawn. */
@Composable
fun DrawScreen(onSave: (List<FloatArray>, Int) -> Unit, onClose: () -> Unit) {
    BackHandler(onBack = onClose)
    var modeIndex by remember { mutableIntStateOf(0) }
    val strokes = remember { mutableStateListOf<FloatArray>() }   // finished strokes, x,y in -1..1 (y up)
    var current by remember { mutableStateOf<List<Float>>(emptyList()) }
    val mode = MODES[modeIndex].second

    Column(
        Modifier
            .fillMaxSize()
            .background(Ph.Bg)
            .safeDrawingPadding()
            .padding(horizontal = 20.dp, vertical = 14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Draw a trace", style = PhType.title, color = Ph.Ink,
                modifier = Modifier.weight(1f).semantics { heading() })
            ChipButton("Cancel") { onClose() }
        }
        Segmented(MODES.map { it.first }, modeIndex, { modeIndex = it }, modifier = Modifier.padding(top = 14.dp))
        Note(
            when (mode) {
                CustomShapes.LATHE -> "Draw a profile on one side of the axis: a vase, a bottle, a chess piece. It gets spun into a 3D wireframe."
                CustomShapes.EXTRUDE -> "Draw anything; it gets depth, like a cookie cutter, with struts joining front and back."
                else -> "Draw anything; it stays flat and spins like a card."
            },
            modifier = Modifier.padding(bottom = 12.dp),
        )

        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
            Canvas(
                Modifier
                    .fillMaxWidth()
                    .aspectRatio(1f)
                    .semantics { contentDescription = "Drawing area. ${strokes.size} strokes." }
                    .pointerInput(Unit) {
                        fun norm(o: Offset): Pair<Float, Float> {
                            val s = size.width.toFloat()
                            return (o.x / s * 2f - 1f).coerceIn(-1f, 1f) to (1f - o.y / s * 2f).coerceIn(-1f, 1f)
                        }
                        detectDragGestures(
                            onDragStart = { o -> val (x, y) = norm(o); current = listOf(x, y); Haptics.tick() },
                            onDragEnd = {
                                if (current.size >= 4) strokes.add(current.toFloatArray())
                                current = emptyList()
                            },
                            onDragCancel = { current = emptyList() },
                        ) { change, _ ->
                            change.consume()
                            val (x, y) = norm(change.position)
                            val c = current
                            if (c.size >= 2 && hypot(x - c[c.size - 2], y - c[c.size - 1]) > 0.025f) current = c + listOf(x, y)
                        }
                    }
            ) {
                val s = size.minDimension
                val c = Offset(size.width / 2, size.height / 2)
                drawCircle(Ph.Screen, s / 2, c)
                drawCircle(Ph.Rule, s / 2 - 2.dp.toPx(), c, style = Stroke(1.5.dp.toPx()))
                if (mode == CustomShapes.LATHE) drawLine(
                    Ph.Decor, Offset(c.x, 12.dp.toPx()), Offset(c.x, size.height - 12.dp.toPx()),
                    strokeWidth = 1.5.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(18f, 14f)),
                )
                fun draw(pts: List<Float>) {
                    if (pts.size < 4) return
                    val p = Path()
                    for (i in pts.indices step 2) {
                        val x = (pts[i] + 1f) / 2f * size.width
                        val y = (1f - (pts[i + 1] + 1f) / 2f) * size.height
                        if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
                    }
                    drawPath(p, Ph.Active.copy(alpha = 0.3f), style = Stroke(9.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
                    drawPath(p, Ph.LedOn, style = Stroke(3.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
                }
                strokes.forEach { draw(it.toList()) }
                draw(current)
            }
        }

        Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(Modifier.weight(1f)) {
                GhostButton("Undo") { if (strokes.isNotEmpty()) strokes.removeAt(strokes.size - 1) }
            }
            Box(Modifier.weight(1f)) {
                GhostButton("Clear", Ph.Danger) { strokes.clear(); Haptics.reject() }
            }
        }
        PrimaryButton("Save trace") {
            if (strokes.isEmpty()) { Haptics.reject() } else onSave(strokes.toList(), mode)
        }
    }
}
