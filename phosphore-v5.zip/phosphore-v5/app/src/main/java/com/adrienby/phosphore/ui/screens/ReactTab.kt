package com.adrienby.phosphore.ui.screens

import androidx.compose.runtime.Composable
import com.adrienby.phosphore.ui.AppViewModel
import com.adrienby.phosphore.ui.components.ChipButton
import com.adrienby.phosphore.ui.components.ChipRow
import com.adrienby.phosphore.ui.components.Fader
import com.adrienby.phosphore.ui.components.Note
import com.adrienby.phosphore.ui.components.SectionCard
import com.adrienby.phosphore.ui.components.ToggleRow
import com.adrienby.phosphore.ui.theme.Ph

@Composable
fun ReactTab(vm: AppViewModel, onNotifAccess: () -> Unit, onNeedAudio: () -> Unit) = TabPage {
    val s = vm.settings
    val d = vm.defaults

    SectionCard("Notifications") {
        ToggleRow("Flash on new notifications",
            if (vm.notifAccess) "Notification access granted" else "Needs notification access",
            s.notifPulse) { on ->
            vm.change { it.copy(notifPulse = on) }
            if (on && !vm.notifAccess) onNotifAccess()
        }
        ChipRow { ChipButton("Notification access") { onNotifAccess() } }
    }

    SectionCard("Charging") {
        ToggleRow("Battery fill",
            "While plugged in, only the battery's share of the trace is drawn bright. Works on the Always-on toy too.",
            s.batteryFill) { on -> vm.change { it.copy(batteryFill = on) } }
    }

    SectionCard("Music") {
        ToggleRow("Move with the music",
            "Spin follows loudness and the beam flashes on beats. Listens to the phone's own audio output; Android shows the mic indicator while it's on.",
            s.beatSync) { on ->
            vm.change { it.copy(beatSync = on) }
            if (on) onNeedAudio()
        }
        Fader("Response", s.beatAmount, d.beatAmount, ::pct) { v -> vm.change { it.copy(beatAmount = v) } }
        if (vm.live.music.isNotEmpty()) Note(vm.live.music, Ph.Active)
    }
}
