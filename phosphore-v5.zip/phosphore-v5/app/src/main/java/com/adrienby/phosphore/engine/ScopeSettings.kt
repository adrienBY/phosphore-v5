package com.adrienby.phosphore.engine

import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.pow

/** Knobs are stored normalised to 0..1; mapping to physical units lives in the companion. */
data class ScopeSettings(
    // trace
    val shapeId: String = "Cube",
    val autoCycle: Int = 0,          // seconds, 0 = off
    val shuffle: Boolean = false,
    val morphMs: Int = 1000,         // 0 = cut
    // reactive
    val hologram: Boolean = false,
    val notifPulse: Boolean = false,
    val batteryFill: Boolean = false,
    val beatSync: Boolean = false,
    val beatAmount: Float = 0.5f,
    // motion
    val spinMode: Int = SPIN_TURNTABLE,
    val rotation: Float = 1f,
    val size: Float = 1f,
    // beam
    val sweep: Float = 1f,
    val sweepLfo: Boolean = false,
    val lfoShape: Int = LFO_SINE,
    val lfoRate: Float = 0.45f,
    val lfoDepth: Float = 0.5f,
    val bandwidth: Float = 1f,
    val focus: Float = 0f,
    // phosphor
    val persistence: Float = 0.033f,   // 35 ms
    val intensity: Float = 0.15f,
    val contrast: Float = 1f,
    val depth: Float = 0f,
    val noise: Float = 0.12f,
    val breathing: Float = 0f,
    // glyph matrix output
    val mirror: Boolean = true,
    val background: Boolean = true,
    val screenOff: Boolean = true,
    val sleepMinutes: Int = 30,      // 0 = never
    val matrixFps: Int = 30,
    val brightness: Float = 0.53f,
    val invert: Boolean = false,
    val flipX: Boolean = false,
    val rotate: Int = 0,             // 0, 90, 180, 270
    // always-on toy
    val aodMinutes: Int = 5,         // 0 = no limit
    // app
    val haptics: Boolean = true,
    val tab: Int = 0,
) {
    /** Look-related knobs from [p], keeping this one's trace and output options. */
    fun withLook(p: ScopeSettings) = copy(
        spinMode = p.spinMode, rotation = p.rotation, size = p.size,
        sweep = p.sweep, sweepLfo = p.sweepLfo, lfoShape = p.lfoShape, lfoRate = p.lfoRate, lfoDepth = p.lfoDepth,
        bandwidth = p.bandwidth, focus = p.focus,
        persistence = p.persistence, intensity = p.intensity, contrast = p.contrast,
        depth = p.depth, noise = p.noise, breathing = p.breathing,
    )

    companion object {
        const val SPIN_TUMBLE = 0
        const val SPIN_TURNTABLE = 1
        const val SPIN_STILL = 2

        const val LFO_SINE = 0
        const val LFO_TRIANGLE = 1
        const val LFO_PULSE = 2
        const val LFO_DRIFT = 3

        /** Seconds per oscillation: 60 s .. 0.5 s. */
        fun lfoPeriod(v: Float) = 60f * exp(-v * ln(120f))
        /** Swing either side of the Sweep knob, in octaves (×2 per octave): 0 .. 4. */
        fun lfoOctaves(v: Float) = 4f * v

        fun rotationRadPerSec(v: Float) = 3f * v.pow(1.5f)
        fun sizeMul(v: Float) = 0.7f + 0.6f * v
        fun sweepHz(v: Float) = 0.15f * exp(v * ln(400f / 0.15f))
        fun persistenceSec(v: Float) = 0.03f * exp(v * ln(100f))
        fun focusSigma(v: Float) = 0.30f + 0.90f * v
        fun bandwidthHarmonics(v: Float) = 4f * exp(v * ln(60f))
        fun bandwidthOmega(v: Float) = (2.0 * PI).toFloat() * bandwidthHarmonics(v)
        fun gain(v: Float) = 0.2f + 2.6f * v * v
        fun gamma(v: Float) = 1f + 1.6f * v

        /** The v1/v2 look; the other presets are variations on it. */
        private fun classic(
            spinMode: Int = SPIN_TUMBLE, rotation: Float = 0.35f, size: Float = 0.5f,
            sweep: Float = 0.7f, bandwidth: Float = 0.55f, focus: Float = 0.22f,
            persistence: Float = 0.45f, intensity: Float = 0.55f, contrast: Float = 0.375f,
            depth: Float = 0.5f, noise: Float = 0.12f, breathing: Float = 0f,
        ) = ScopeSettings(brightness = 1f, spinMode = spinMode, rotation = rotation, size = size, sweep = sweep,
            bandwidth = bandwidth, focus = focus, persistence = persistence, intensity = intensity,
            contrast = contrast, depth = depth, noise = noise, breathing = breathing)

        val PRESETS: List<Pair<String, ScopeSettings>> = listOf(
            "Default" to ScopeSettings(),
            "Classic" to ScopeSettings(spinMode = SPIN_TUMBLE, rotation = 0.35f, size = 0.5f,
                sweep = 0.7f, bandwidth = 0.55f, focus = 0.22f, persistence = 0.45f,
                intensity = 0.55f, contrast = 0.375f, depth = 0.5f, noise = 0.12f),
            "Vector" to classic(sweep = 0.9f, bandwidth = 0.92f, focus = 0.04f,
                persistence = 0.3f, intensity = 0.62f, contrast = 0.55f, noise = 0f),
            "Slow draw" to classic(rotation = 0.2f, sweep = 0.27f, bandwidth = 0.5f,
                persistence = 0.62f, intensity = 0.6f, noise = 0.05f),
            "Afterglow" to classic(rotation = 0.42f, sweep = 0.62f, persistence = 0.86f,
                intensity = 0.42f, contrast = 0.5f),
            "Analog" to classic(bandwidth = 0.18f, focus = 0.5f, noise = 0.6f,
                breathing = 0.25f, persistence = 0.5f),
            "Turntable" to classic(spinMode = SPIN_TURNTABLE, rotation = 0.3f, depth = 0.8f),
            "Breathing scan" to ScopeSettings(sweep = 0.5f, sweepLfo = true, lfoShape = LFO_SINE,
                lfoRate = 0.35f, lfoDepth = 0.55f, persistence = 0.35f, intensity = 0.35f),
            "Glitch" to ScopeSettings(sweep = 0.55f, sweepLfo = true, lfoShape = LFO_DRIFT,
                lfoRate = 0.75f, lfoDepth = 0.8f, noise = 0.45f, persistence = 0.2f, intensity = 0.3f),
        )
    }
}
