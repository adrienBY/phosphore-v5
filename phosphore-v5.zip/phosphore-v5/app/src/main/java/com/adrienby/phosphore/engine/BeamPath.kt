package com.adrienby.phosphore.engine

import kotlin.math.max
import kotlin.math.sqrt

/**
 * A closed beam path: flattened segments with a beam weight each (1 = drawn, 0 = blanked,
 * in-between while morphing), parametrised by cumulative length.
 */
class BeamPath {
    var n = 0
        private set
    var total = 1f
        private set
    private var a = FloatArray(0)
    private var b = FloatArray(0)
    private var start = FloatArray(0)
    private var len = FloatArray(0)
    var w = FloatArray(0)
        private set

    private fun ensure(cap: Int) {
        if (start.size >= cap) return
        a = FloatArray(cap * 3); b = FloatArray(cap * 3)
        start = FloatArray(cap); len = FloatArray(cap); w = FloatArray(cap)
    }

    /** Strokes are drawn; jumps between them (and back to the start) are blanked retraces. */
    fun fromStrokes(strokes: List<FloatArray>) {
        var cap = 1
        for (s in strokes) cap += max(0, s.size / 3 - 1) + 1
        ensure(cap)
        var k = 0
        var cum = 0f
        fun add(p: FloatArray, pi: Int, q: FloatArray, qi: Int, on: Boolean) {
            val dx = q[qi] - p[pi]; val dy = q[qi + 1] - p[pi + 1]; val dz = q[qi + 2] - p[pi + 2]
            val d = sqrt(dx * dx + dy * dy + dz * dz)
            val l = if (on) d else if (d < 1e-4f) return else d * 0.55f + 0.06f
            val k3 = k * 3
            a[k3] = p[pi]; a[k3 + 1] = p[pi + 1]; a[k3 + 2] = p[pi + 2]
            b[k3] = q[qi]; b[k3 + 1] = q[qi + 1]; b[k3 + 2] = q[qi + 2]
            start[k] = cum; len[k] = l; w[k] = if (on) 1f else 0f
            cum += l; k++
        }
        for ((si, s) in strokes.withIndex()) {
            val pts = s.size / 3
            if (pts == 0) continue
            for (j in 0 until pts - 1) add(s, j * 3, s, (j + 1) * 3, true)
            val next = strokes[(si + 1) % strokes.size]
            if (next.size >= 3) add(s, (pts - 1) * 3, next, 0, false)
        }
        if (k == 0) {                   // degenerate: a single dot
            a[0] = 0f; a[1] = 0f; a[2] = 0f; b[0] = 0f; b[1] = 0f; b[2] = 0f
            start[0] = 0f; len[0] = 1f; w[0] = 0f; k = 1; cum = 1f
        }
        n = k
        total = max(cum, 1e-3f)
    }

    /** Closed loop through [count] points, segment i weighted by wts[i]. */
    fun fromLoop(pts: FloatArray, wts: FloatArray, count: Int) {
        ensure(count)
        var cum = 0f
        for (i in 0 until count) {
            val j = (i + 1) % count
            val i3 = i * 3; val j3 = j * 3
            a[i3] = pts[i3]; a[i3 + 1] = pts[i3 + 1]; a[i3 + 2] = pts[i3 + 2]
            b[i3] = pts[j3]; b[i3 + 1] = pts[j3 + 1]; b[i3 + 2] = pts[j3 + 2]
            val dx = b[i3] - a[i3]; val dy = b[i3 + 1] - a[i3 + 1]; val dz = b[i3 + 2] - a[i3 + 2]
            // blanked stretches still take some beam time, as in a real retrace
            val d = sqrt(dx * dx + dy * dy + dz * dz)
            val wt = wts[i]
            val l = d * (0.55f + 0.45f * wt) + (1f - wt) * 0.004f
            start[i] = cum; len[i] = l; w[i] = wt
            cum += l
        }
        n = count
        total = max(cum, 1e-3f)
    }

    fun locate(s: Float): Int {
        var lo = 0; var hi = n - 1
        while (lo < hi) {
            val mid = (lo + hi + 1) ushr 1
            if (start[mid] <= s) lo = mid else hi = mid - 1
        }
        return lo
    }

    /** Advances [seg] monotonically from a previous position; returns the new segment. */
    fun advance(seg: Int, s: Float): Int {
        var k = seg
        while (k < n - 1 && start[k + 1] <= s) k++
        return k
    }

    /** Point at arc length [s] within segment [seg] -> out[o..o+2]; returns the beam weight. */
    fun point(seg: Int, s: Float, out: FloatArray, o: Int): Float {
        val f = if (len[seg] > 1e-6f) ((s - start[seg]) / len[seg]).coerceIn(0f, 1f) else 0f
        val i3 = seg * 3
        out[o] = a[i3] + (b[i3] - a[i3]) * f
        out[o + 1] = a[i3 + 1] + (b[i3 + 1] - a[i3 + 1]) * f
        out[o + 2] = a[i3 + 2] + (b[i3 + 2] - a[i3 + 2]) * f
        return w[seg]
    }

    /** Uniform resampling into [count] points (pos + weight), used for morphing. */
    fun resample(count: Int, pts: FloatArray, wts: FloatArray) {
        var seg = 0
        for (i in 0 until count) {
            val s = (i + 0.5f) / count * total
            seg = advance(seg, s)
            wts[i] = point(seg, s, pts, i * 3)
        }
    }
}
