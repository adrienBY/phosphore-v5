package com.adrienby.phosphore.ui.components

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.FloatState
import androidx.compose.runtime.IntState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.CustomAccessibilityAction
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.customActions
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.adrienby.phosphore.PlayerService
import com.adrienby.phosphore.ui.Haptics
import com.adrienby.phosphore.ui.theme.Ph
import com.adrienby.phosphore.ui.theme.PhType
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.tanh

// ======================================================================= matrix preview

/**
 * On-screen twin of the Glyph Matrix. Redraws when [frame] ticks, without recomposing.
 * Drag to spin the trace (with low ticks as it turns). Screen readers get a description and
 * Next / Previous actions.
 */
@Composable
fun MatrixPreview(
    n: Int,
    mask: BooleanArray,
    levels: FloatArray,
    frame: IntState,
    description: String,
    onDrag: (dYaw: Float, dPitch: Float, dt: Float) -> Unit,
    onRelease: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val drag by rememberUpdatedState(onDrag)
    val release by rememberUpdatedState(onRelease)
    val lastT = remember { mutableLongStateOf(0L) }
    val travel = remember { mutableFloatStateOf(0f) }
    Canvas(
        modifier
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = { lastT.longValue = System.nanoTime(); travel.floatValue = 0f; Haptics.dragStart() },
                    onDragEnd = { release() },
                    onDragCancel = { release() },
                ) { change, amount ->
                    change.consume()
                    val k = (PI / size.width).toFloat()
                    val now = System.nanoTime()
                    val dt = max(1L, now - lastT.longValue) / 1e9f
                    lastT.longValue = now
                    val dYaw = amount.x * k; val dPitch = amount.y * k
                    drag(dYaw, dPitch, dt)
                    travel.floatValue += abs(dYaw) + abs(dPitch)
                    if (travel.floatValue > 0.42f) { travel.floatValue = 0f; Haptics.spin() }
                }
            }
            .semantics {
                contentDescription = description
                customActions = listOf(
                    CustomAccessibilityAction("Next trace") { onNext(); true },
                    CustomAccessibilityAction("Previous trace") { onPrevious(); true },
                )
            }
    ) {
        frame.intValue                                   // subscribe: redraw every new frame
        val w = size.minDimension
        val c = Offset(size.width / 2, size.height / 2)
        drawCircle(Ph.Screen, w / 2, c)
        drawCircle(Ph.Rule, w / 2 - 3.dp.toPx(), c, style = Stroke(1.5.dp.toPx()))
        drawDots(n, mask, levels, c.x - w * 0.45f, c.y - w * 0.45f, w * 0.9f, halo = true)
    }
}

/** Dots for an n×n LED layout inside a [box]-sized square at (x0, y0). */
fun DrawScope.drawDots(n: Int, mask: BooleanArray, levels: FloatArray?, x0: Float, y0: Float, box: Float, halo: Boolean) {
    val pitch = box / n
    val r = pitch * 0.34f
    for (y in 0 until n) for (x in 0 until n) {
        val i = y * n + x
        if (!mask[i]) continue
        val center = Offset(x0 + (x + 0.5f) * pitch, y0 + (y + 0.5f) * pitch)
        // LED light is linear in drive; the screen is sRGB, so encode before drawing.
        val v = (levels?.get(i) ?: 0f).coerceIn(0f, 1f).pow(1f / 2.2f)
        if (halo && v > 0.02f) drawCircle(Ph.LedOn.copy(alpha = 0.35f * v * v), r * 1.75f, center)
        drawCircle(lerp(Ph.LedOff, Ph.LedOn, v), r, center)
    }
}

// ======================================================================= shape tile

const val TILE_SHAPE = 0
const val TILE_DRAW = 1
const val TILE_IMPORT = 2

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ShapeTile(
    name: String,
    kind: Int,
    isSelected: Boolean,
    n: Int,
    mask: BooleanArray,
    thumb: FloatArray?,
    onClick: () -> Unit,
    onLongClick: (() -> Unit)? = null,
) {
    val src = remember { MutableInteractionSource() }
    val sel by animateFloatAsState(if (isSelected) 1f else 0f, tween(220), label = "tile")
    val shape = RoundedCornerShape(16.dp)
    Column(
        Modifier
            .width(86.dp)
            .pressable(src, 0.94f)
            .clip(shape)
            .background(lerp(Ph.SurfaceHi, Color(0xFF2D4352), sel))
            .border(2.dp, Ph.Active.copy(alpha = sel), shape)
            .combinedClickable(
                interactionSource = src,
                indication = ripple(),
                role = Role.Button,
                onLongClickLabel = if (onLongClick != null) "Delete" else null,
                onLongClick = onLongClick,
                onClick = { Haptics.detent(); onClick() },
            )
            .semantics(mergeDescendants = true) {
                contentDescription = name
                if (kind == TILE_SHAPE) {
                    selected = isSelected
                    stateDescription = if (isSelected) "Playing" else ""
                }
            }
            .padding(top = 10.dp, bottom = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Canvas(Modifier.size(58.dp)) {
            when (kind) {
                TILE_SHAPE -> drawDots(n, mask, thumb, 0f, 0f, size.minDimension, halo = false)
                TILE_DRAW -> {
                    val s = size.minDimension
                    val p = Path().apply {
                        moveTo(s * 0.22f, s * 0.78f)
                        cubicTo(s * 0.30f, s * 0.15f, s * 0.62f, s * 0.95f, s * 0.80f, s * 0.22f)
                    }
                    drawPath(p, Ph.Active, style = Stroke(2.4.dp.toPx(), cap = StrokeCap.Round))
                    drawCircle(Ph.Active, 3.dp.toPx(), Offset(s * 0.80f, s * 0.22f))
                }
                else -> {
                    val s = size.minDimension
                    val st = Stroke(2.4.dp.toPx(), cap = StrokeCap.Round)
                    val a = s * 0.24f; val cx = s / 2; val cy = s / 2; val o = a * 0.45f
                    val front = Path().apply {
                        moveTo(cx - a, cy - a + o); lineTo(cx + a - o, cy - a + o); lineTo(cx + a - o, cy + a)
                        lineTo(cx - a, cy + a); close()
                    }
                    val back = Path().apply {
                        moveTo(cx - a, cy - a + o); lineTo(cx - a + o, cy - a); lineTo(cx + a, cy - a)
                        lineTo(cx + a, cy + a - o); lineTo(cx + a - o, cy + a)
                        moveTo(cx + a - o, cy - a + o); lineTo(cx + a, cy - a)
                    }
                    drawPath(front, Ph.Active, style = st)
                    drawPath(back, Ph.Active, style = st)
                }
            }
        }
        Text(
            name, style = PhType.tile, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center,
            color = lerp(Ph.InkDim, Ph.Ink, if (kind == TILE_SHAPE) sel else 1f),
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp, start = 6.dp, end = 6.dp),
        )
    }
}

// ======================================================================= status pill

@Composable
fun StatusPill(state: Int) {
    val (label, color, live) = when (state) {
        PlayerService.STATE_LIVE -> Triple("On the matrix", Ph.Live, true)
        PlayerService.STATE_CONNECTING -> Triple("Connecting", Ph.Warn, false)
        PlayerService.STATE_NONE -> Triple("Preview only", Ph.InkFaint, false)
        else -> Triple("Matrix off", Ph.InkFaint, false)
    }
    val pulse by rememberInfiniteTransition(label = "pill").animateFloat(
        0.25f, 1f, infiniteRepeatable(tween(850), RepeatMode.Reverse), label = "pulse",
    )
    Row(
        Modifier
            .clip(RoundedCornerShape(50))
            .background(Ph.Surface)
            .padding(start = 10.dp, end = 12.dp, top = 6.dp, bottom = 6.dp)
            .semantics(mergeDescendants = true) { liveRegion = LiveRegionMode.Polite },
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Canvas(Modifier.size(14.dp)) {
            if (live) drawCircle(color.copy(alpha = 0.35f * pulse), size.minDimension / 2)
            drawCircle(color, 3.5.dp.toPx())
        }
        Text(label, style = PhType.caption.copy(letterSpacing = 0.5.sp), color = Ph.Ink, modifier = Modifier.padding(start = 6.dp))
    }
}

// ======================================================================= transport

const val ICON_PREV = 0
const val ICON_NEXT = 1
const val ICON_POWER = 2

@Composable
fun TransportButton(kind: Int, description: String, active: Boolean = false, big: Boolean = false, onClick: () -> Unit) {
    val src = remember { MutableInteractionSource() }
    val t by animateFloatAsState(if (active) 1f else 0f, tween(240), label = "transport")
    val d = if (big) 52.dp else 44.dp
    Box(
        Modifier
            .size(d)
            .pressable(src, 0.88f)
            .clip(CircleShape)
            .background(lerp(Ph.Surface, Ph.Active, t))
            .clickable(interactionSource = src, indication = ripple(), role = Role.Button, onClickLabel = description) { onClick() }
            .semantics {
                contentDescription = description
                if (kind == ICON_POWER) stateDescription = if (active) "On" else "Off"
            },
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.size(d)) {
            val col = lerp(Ph.Ink, Ph.Screen, t)
            val s = size.minDimension
            val cx = s / 2; val cy = s / 2; val k = s * 0.16f
            when (kind) {
                ICON_PREV, ICON_NEXT -> {
                    val dir = if (kind == ICON_NEXT) 1f else -1f
                    for (o in floatArrayOf(-0.55f, 0.45f)) {
                        val x = cx + o * k * dir
                        val p = Path().apply {
                            moveTo(x - k * 0.5f * dir, cy - k * 0.8f)
                            lineTo(x + k * 0.6f * dir, cy)
                            lineTo(x - k * 0.5f * dir, cy + k * 0.8f)
                            close()
                        }
                        drawPath(p, col)
                    }
                }
                else -> {
                    val r = k * 1.05f
                    val st = Stroke(2.2.dp.toPx(), cap = StrokeCap.Round)
                    drawArc(col, -60f, 300f, false, Offset(cx - r, cy - r), androidx.compose.ui.geometry.Size(2 * r, 2 * r), style = st)
                    drawLine(col, Offset(cx, cy - r * 1.25f), Offset(cx, cy - r * 0.15f), strokeWidth = st.width, cap = StrokeCap.Round)
                }
            }
        }
    }
}

// ======================================================================= LFO scope

/** The sweep oscillator's waveform with a dot riding on it; redraws per frame without recomposing. */
@Composable
fun LfoScope(shape: Int, on: Boolean, position: FloatState, value: FloatState, hzText: String) {
    Box(
        Modifier
            .fillMaxWidth()
            .padding(top = 8.dp)
            .height(76.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(Ph.Screen)
            .semantics(mergeDescendants = true) {
                contentDescription = if (on) "Sweep oscillator, now $hzText" else "Sweep oscillator off"
            }
    ) {
        Canvas(Modifier.fillMaxWidth().height(76.dp)) {
            val padX = 14.dp.toPx()
            val top = 12.dp.toPx(); val bottom = size.height - 12.dp.toPx()
            val mid = (top + bottom) / 2; val amp = (bottom - top) / 2
            val right = size.width * 0.64f
            drawLine(Ph.Rule, Offset(padX, mid), Offset(size.width - padX, mid), strokeWidth = 1.dp.toPx())
            val path = Path()
            for (i in 0..96) {
                val p = i / 96f
                val x = padX + (right - padX) * p
                val y = mid - amp * wave(shape, p)
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            drawPath(path, if (on) Ph.Active else Ph.Decor, style = Stroke(2.dp.toPx(), cap = StrokeCap.Round))
            if (on) {
                val ph = position.floatValue
                val x = padX + (right - padX) * ph
                val y = mid - amp * (if (shape == 3) value.floatValue else wave(shape, ph))
                drawCircle(Ph.Active.copy(alpha = 0.3f), 9.dp.toPx(), Offset(x, y))
                drawCircle(Ph.LedOn, 4.dp.toPx(), Offset(x, y))
            }
        }
        Column(Modifier.align(Alignment.CenterEnd).padding(end = 14.dp), horizontalAlignment = Alignment.End) {
            Text(if (on) hzText.removeSuffix(" Hz") else "off", style = PhType.nowPlaying.copy(fontSize = 20.sp, fontFeatureSettings = "tnum"),
                color = if (on) Ph.Ink else Ph.InkFaint)
            if (on) Text("Hz now", style = PhType.note.copy(fontSize = 11.5.sp), color = Ph.InkFaint)
        }
    }
}

private fun wave(shape: Int, p: Float): Float = when (shape) {
    1 -> 1f - 4f * abs(((p + 0.25f) % 1f) - 0.5f)
    2 -> tanh(3.5f * sin(6.2832f * p)) / tanh(3.5f)
    3 -> 0.6f * sin(6.2832f * p + 0.7f) + 0.4f * sin(6.2832f * p * 2.3f)   // illustrative only
    else -> sin(6.2832f * p)
}
