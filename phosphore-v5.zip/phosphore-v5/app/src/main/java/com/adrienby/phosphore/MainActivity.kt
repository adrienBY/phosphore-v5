package com.adrienby.phosphore

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.Bundle
import android.os.IBinder
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.adrienby.phosphore.ui.AppViewModel
import com.adrienby.phosphore.ui.Haptics
import com.adrienby.phosphore.ui.screens.MainScreen
import com.adrienby.phosphore.ui.theme.PhosphoreTheme

/** Thin host: edge-to-edge Compose UI, and the bind/unbind dance with the player service. */
class MainActivity : ComponentActivity() {

    private val vm: AppViewModel by viewModels()
    private var bound = false

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            vm.attach((binder as PlayerService.LocalBinder).service)
        }
        override fun onServiceDisconnected(name: ComponentName?) = vm.detach()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        Haptics.init(this)
        setContent { PhosphoreTheme { MainScreen(vm) } }
    }

    override fun onStart() {
        super.onStart()
        vm.syncForeground()
        bound = bindService(Intent(this, PlayerService::class.java), connection, Context.BIND_AUTO_CREATE)
    }

    override fun onResume() {
        super.onResume()
        vm.refreshNotifAccess()
    }

    override fun onStop() {
        vm.detach()
        if (bound) { unbindService(connection); bound = false }
        super.onStop()
    }
}
