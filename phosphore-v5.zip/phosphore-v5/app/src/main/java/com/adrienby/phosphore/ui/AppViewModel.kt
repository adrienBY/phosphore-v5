package com.adrienby.phosphore.ui

import android.app.Application
import android.app.NotificationManager
import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.adrienby.phosphore.Device
import com.adrienby.phosphore.NotifListener
import com.adrienby.phosphore.PlayerService
import com.adrienby.phosphore.SettingsStore
import com.adrienby.phosphore.engine.CustomShapes
import com.adrienby.phosphore.engine.ScopeEngine
import com.adrienby.phosphore.engine.ScopeSettings
import com.adrienby.phosphore.engine.Shape
import com.adrienby.phosphore.engine.ShapeLibrary
import com.adrienby.phosphore.engine.Shapes
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.roundToInt

/** Values that change every frame. Kept apart so only what reads them redraws. */
class LiveState {
    val frame = mutableIntStateOf(0)
    var shapeId by mutableStateOf("")
    var glyphState by mutableIntStateOf(PlayerService.STATE_CONNECTING)
    var sweepText by mutableStateOf("")
    val sweepHz = mutableFloatStateOf(0f)
    val lfoPos = mutableFloatStateOf(0f)
    val lfoValue = mutableFloatStateOf(0f)
    var music by mutableStateOf("")
}

sealed interface UiEvent {
    /** Snackbar with Undo. [dismissed] runs if the user lets it go. */
    class Undoable(val message: String, val undo: () -> Unit, val dismissed: () -> Unit = {}) : UiEvent
    class Message(val text: String) : UiEvent
}

class AppViewModel(app: Application) : AndroidViewModel(app) {

    private val ctx: Application get() = getApplication()

    val n = Device.matrixLength
    val mask = ScopeEngine.maskFor(n)
    val levels = FloatArray(n * n)
    val live = LiveState()
    val defaults = ScopeSettings()

    var settings by mutableStateOf(SettingsStore.load(app))
        private set
    private val library = ShapeLibrary(SettingsStore.shapesDir(app))
    var shapes by mutableStateOf<List<Shape>>(library.shapes)
        private set
    val thumbs = mutableStateMapOf<String, FloatArray>()
    var player by mutableStateOf<PlayerService?>(null)
        private set
    var notifAccess by mutableStateOf(false)
        private set
    var drawing by mutableStateOf(false)

    private val _events = MutableSharedFlow<UiEvent>(extraBufferCapacity = 8)
    val events: SharedFlow<UiEvent> = _events

    private val main = Handler(Looper.getMainLooper())
    private val saveTask = Runnable { SettingsStore.saveAsync(ctx, settings) }

    init {
        Haptics.enabled = settings.haptics
        live.shapeId = settings.shapeId
        renderThumbs(shapes.map { it.id })
        refreshNotifAccess()
    }

    // ------------------------------------------------------------------ player

    fun attach(p: PlayerService) {
        player = p
        p.apply(settings)
        p.attachUi { msg ->
            if (msg.startsWith("Couldn't") || msg.startsWith("Glyph service refused"))
                _events.tryEmit(UiEvent.Message(msg))
        }
    }

    fun detach() {
        val p = player ?: return
        if (p.currentShapeId.isNotEmpty()) settings = settings.copy(shapeId = p.currentShapeId)
        main.removeCallbacks(saveTask)
        SettingsStore.saveAsync(ctx, settings)
        p.detachUi()
        player = null
    }

    /** Pulls the latest frame and live readouts; call once per display frame. */
    fun poll() {
        val p = player ?: return
        p.snapshot(levels)
        live.frame.intValue++
        if (p.currentShapeId.isNotEmpty()) live.shapeId = p.currentShapeId
        live.glyphState = p.glyphState
        val hz = p.liveSweepHz
        live.sweepHz.floatValue = hz
        live.sweepText = formatHz(hz)
        live.lfoPos.floatValue = p.lfoPosition
        live.lfoValue.floatValue = p.lfoValue
        live.music = p.musicStatus
    }

    fun syncForeground() {
        val s = settings
        if (s.mirror && s.background) {
            try {
                ctx.startForegroundService(Intent(ctx, PlayerService::class.java).setAction(PlayerService.ACTION_PLAY))
            } catch (t: Throwable) {
                _events.tryEmit(UiEvent.Message("Couldn't start background playback: ${t.message}"))
            }
        } else player?.leaveForeground()
    }

    // ------------------------------------------------------------------ settings

    fun update(s: ScopeSettings) {
        val old = settings
        settings = s
        player?.apply(s)
        if (old.mirror != s.mirror || old.background != s.background) syncForeground()
        if (old.haptics != s.haptics) Haptics.enabled = s.haptics
        main.removeCallbacks(saveTask)
        main.postDelayed(saveTask, 250)
    }

    inline fun change(transform: (ScopeSettings) -> ScopeSettings) = update(transform(settings))

    fun setPower(on: Boolean) {
        if (on) Haptics.powerOn() else Haptics.powerOff()
        update(settings.copy(mirror = on))
    }

    fun setTab(i: Int) = update(settings.copy(tab = i))

    fun applyPreset(name: String, preset: ScopeSettings) {
        val before = settings
        update(settings.withLook(preset))
        Haptics.confirm()
        _events.tryEmit(UiEvent.Undoable("$name look applied", undo = { update(settings.withLook(before)) }))
    }

    fun resetAll() {
        val before = settings
        Haptics.enabled = true
        update(ScopeSettings(tab = settings.tab))
        selectShape(defaults.shapeId)
        Haptics.reject()
        _events.tryEmit(UiEvent.Undoable("Settings reset", undo = {
            update(before)
            selectShape(before.shapeId)
        }))
    }

    fun message(text: String) { _events.tryEmit(UiEvent.Message(text)) }

    fun refreshNotifAccess() {
        notifAccess = ctx.getSystemService(NotificationManager::class.java)
            ?.isNotificationListenerAccessGranted(ComponentName(ctx, NotifListener::class.java)) == true
    }

    // ------------------------------------------------------------------ shapes

    fun shapeName(id: String) = shapes.firstOrNull { it.id == id }?.name ?: ""

    fun selectShape(id: String) {
        update(settings.copy(shapeId = id))
        player?.selectShape(id)
        live.shapeId = id
    }

    fun next() { Haptics.press(); player?.nextShape() }
    fun previous() { Haptics.press(); player?.previousShape() }

    fun saveDrawing(strokes: List<FloatArray>, mode: Int) {
        val dir = SettingsStore.shapesDir(ctx)
        val kind = when (mode) { CustomShapes.LATHE -> "Lathe"; CustomShapes.EXTRUDE -> "Extrusion"; else -> "Drawing" }
        val count = shapes.count { it.category == Shapes.CUSTOM } + 1
        val id = CustomShapes.save(dir, "$kind $count", CustomShapes.fromDrawing(strokes, mode))
        Haptics.confirm()
        shapesChanged(id)
    }

    fun importObj(uri: Uri) {
        _events.tryEmit(UiEvent.Message("Importing…"))
        viewModelScope.launch {
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    val name = displayName(uri)?.substringBeforeLast('.')?.take(24) ?: "Model"
                    val text = ctx.contentResolver.openInputStream(uri)!!.use { input ->
                        val bytes = input.readBytes()
                        require(bytes.size < 40_000_000) { "File too large" }
                        String(bytes, Charsets.UTF_8)
                    }
                    val r = CustomShapes.importObj(text)
                    CustomShapes.save(SettingsStore.shapesDir(ctx), name, r.strokes) to "$name: ${r.note}"
                }
            }
            result.onSuccess { (id, note) ->
                shapesChanged(id)
                Haptics.confirm()
                _events.tryEmit(UiEvent.Message(note))
            }.onFailure {
                Haptics.reject()
                _events.tryEmit(UiEvent.Message("Import failed: ${it.message ?: "couldn't read this file"}"))
            }
        }
    }

    /** Moves the trace to a trash folder; Undo brings it back, dismissing deletes it for good. */
    fun deleteCustom(id: String) {
        if (!id.startsWith("custom:")) return
        val name = shapeName(id)
        val file = File(SettingsStore.shapesDir(ctx), id.removePrefix("custom:"))
        val trash = File(ctx.cacheDir, "trash").apply { mkdirs() }
        val parked = File(trash, file.name)
        if (!file.renameTo(parked)) return
        Haptics.reject()
        if (live.shapeId == id) selectShape(defaults.shapeId)
        shapesChanged(null)
        _events.tryEmit(UiEvent.Undoable("Deleted $name",
            undo = { if (parked.renameTo(file)) shapesChanged(id) },
            dismissed = { parked.delete() }))
    }

    private fun shapesChanged(select: String?) {
        library.reload()
        shapes = library.shapes
        player?.reloadShapes()
        renderThumbs(shapes.filter { it.category == Shapes.CUSTOM && it.id !in thumbs }.map { it.id })
        if (select != null) selectShape(select)
    }

    private fun renderThumbs(ids: List<String>) {
        if (ids.isEmpty()) return
        Thumbs.render(library, n, ids) { id, lv -> thumbs[id] = lv }
    }

    private fun displayName(uri: Uri): String? = try {
        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
    } catch (_: Throwable) { null }

    companion object {
        fun formatHz(hz: Float) = if (hz < 10f) "%.1f Hz".format(hz) else "%d Hz".format(hz.roundToInt())
    }
}
