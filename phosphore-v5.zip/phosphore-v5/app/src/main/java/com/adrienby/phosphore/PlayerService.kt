package com.adrienby.phosphore

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.os.Binder
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import com.adrienby.phosphore.engine.ScopeEngine
import com.adrienby.phosphore.engine.ScopeSettings
import com.adrienby.phosphore.engine.ShapeLibrary
import kotlin.math.min

/**
 * Owns the one engine instance and drives the Glyph Matrix from a render thread.
 *
 * - While the app is open, the activity binds to it and reads frames for the preview.
 * - With "keep playing" on, the activity also starts it as a foreground service, so it
 *   survives the activity being closed and keeps the matrix running (notification with
 *   Next / Stop). Optionally holds a partial wake lock so it keeps going with the screen off.
 */
class PlayerService : Service() {

    inner class LocalBinder : Binder() {
        val service: PlayerService get() = this@PlayerService
    }

    private val binder = LocalBinder()
    private val main = Handler(Looper.getMainLooper())
    private val thread = HandlerThread("phosphore-render").apply { start() }
    private val render = Handler(thread.looper)

    private val n = Device.matrixLength
    private val library by lazy { ShapeLibrary(SettingsStore.shapesDir(this)) }
    private lateinit var engine: ScopeEngine
    private val snapshot = FloatArray(n * n)
    private val frameLevels = FloatArray(n * n)      // render thread only
    private val led = IntArray(n * n)
    private val lock = Any()

    @Volatile private var settings = ScopeSettings()
    @Volatile var currentShapeId = ""
        private set
    @Volatile var musicStatus = ""
        private set
    @Volatile var liveSweepHz = 0f
        private set
    @Volatile var lfoPosition = 0f
        private set
    @Volatile var lfoValue = 0f
        private set
    private var sleptAt = 0L

    /** For the status pill. */
    val glyphState: Int get() = when {
        !settings.mirror -> STATE_OFF
        !Device.hasMatrix -> STATE_NONE
        glyph?.ready == true -> STATE_LIVE
        else -> STATE_CONNECTING
    }
    @Volatile private var uiAttached = false
    @Volatile private var detachedAt = 0L

    @Volatile private var glyph: GlyphLink? = null
    @Volatile private var pendingPowerOn = false
    @Volatile private var pendingSince = 0L
    private val releaseIfOff = Runnable { if (!settings.mirror) releaseGlyph() }
    private var statusListener: ((String) -> Unit)? = null
    private var lastStatus = ""
    private var foreground = false
    private var wakeLock: PowerManager.WakeLock? = null

    private var lastNs = 0L
    private var pushAcc = 0f
    @Volatile private var running = false

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            val now = System.nanoTime()
            val dt = if (lastNs == 0L) 0f else (now - lastNs) / 1e9f
            lastNs = now
            val s = settings

            // Power on only once the matrix can show it, so the LEDs get the whole animation.
            if (pendingPowerOn) {
                val g0 = glyph
                if (g0?.ready == true || !Device.hasMatrix || SystemClock.uptimeMillis() - pendingSince > 1500L) {
                    pendingPowerOn = false
                    engine.power(true)
                }
            }
            engine.step(dt)
            engine.levels(frameLevels)                       // computed once per tick
            synchronized(lock) { System.arraycopy(frameLevels, 0, snapshot, 0, snapshot.size) }
            liveSweepHz = engine.liveSweepHz
            lfoPosition = engine.lfoPosition
            lfoValue = engine.lfoValue
            if (engine.current.id != currentShapeId) {
                currentShapeId = engine.current.id
                main.post { refreshNotification() }
            }

            val g = glyph
            if (g != null && g.ready) {
                pushAcc += dt
                val period = 1f / s.matrixFps
                if (pushAcc >= period) {
                    pushAcc = min(pushAcc - period, period)
                    ScopeEngine.toLed(frameLevels, led)
                    g.push(led)
                }
            }

            // Sleep timer: stop the matrix, but never kill the loop (a UI may attach later).
            val away = detachedAt
            if (!uiAttached && away > 0L && sleptAt != away && s.sleepMinutes > 0 &&
                SystemClock.uptimeMillis() - away > s.sleepMinutes * 60_000L) {
                sleptAt = away
                main.post { stopPlayback() }
            }
            val delay = if (uiAttached) 16L else (1000L / s.matrixFps).coerceAtLeast(8L)
            render.postDelayed(this, delay)
        }
    }

    // ------------------------------------------------------------------ lifecycle

    override fun onCreate() {
        super.onCreate()
        settings = SettingsStore.load(this)
        val s = settings
        engine = ScopeEngine(n, library)
        render.post { engine.apply(s); engine.power(false, instant = true) }
        if (s.mirror) requestPowerOn()
        currentShapeId = s.shapeId
        createChannel()
        running = true
        render.post(tick)
        Reactive.onNotification = { if (settings.notifPulse) render.post { engine.kick(1f) } }
        syncReactive(null, s)
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopPlayback()
            ACTION_NEXT -> {
                render.post { engine.nextShape() }
                if (!foreground && !uiAttached) stopSelf()
            }
            else -> {                       // ACTION_PLAY
                enterForeground()
                ensureGlyph()
            }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        running = false
        Reactive.onNotification = null
        stopHologram(); stopBattery(); stopBeat()
        render.removeCallbacksAndMessages(null)
        releaseGlyph()
        releaseWake()
        thread.quitSafely()
        super.onDestroy()
    }

    // ------------------------------------------------------------------ API for the activity (main thread)

    fun attachUi(listener: (String) -> Unit) {
        uiAttached = true
        detachedAt = 0L
        statusListener = listener
        releaseWake()
        if (settings.mirror) { ensureGlyph(); requestPowerOn() }
        listener(lastStatus.ifEmpty { idleText() })
    }

    fun detachUi() {
        uiAttached = false
        statusListener = null
        detachedAt = SystemClock.uptimeMillis()
        if (foreground && settings.screenOff) acquireWake()
    }

    fun apply(s: ScopeSettings) {
        val old = settings
        settings = s
        render.post { engine.apply(s) }
        if (old.mirror != s.mirror) {
            if (s.mirror) { main.removeCallbacks(releaseIfOff); ensureGlyph(); requestPowerOn() }
            else powerDown()
        }
        syncReactive(old, s)
    }

    /** Custom shapes were added or removed. */
    fun reloadShapes() = render.post { library.reload(); engine.libraryChanged() }

    fun recenterHologram() { holoRef = null }

    /** Re-evaluates the music listener (e.g. after the audio permission was granted). */
    fun refreshBeat() {
        stopBeat()
        if (settings.beatSync) startBeat()
        if (foreground) enterForeground(force = true)
    }

    // ------------------------------------------------------------------ reactive inputs

    private fun syncReactive(old: ScopeSettings?, s: ScopeSettings) {
        if (old?.hologram != s.hologram) { if (s.hologram) startHologram() else stopHologram() }
        if (old?.batteryFill != s.batteryFill) { if (s.batteryFill) startBattery() else stopBattery() }
        if (old?.beatSync != s.beatSync) {
            if (s.beatSync) startBeat() else stopBeat()
            if (foreground) enterForeground(force = true)     // add / drop the microphone FGS type
        }
    }

    private var holoRef: FloatArray? = null
    private val holoListener = object : SensorEventListener {
        private val r = FloatArray(9)
        private val b = floatArrayOf(-1f, 1f, -1f)     // viewing the matrix from behind the phone
        override fun onSensorChanged(e: SensorEvent) {
            SensorManager.getRotationMatrixFromVector(r, e.values)
            val ref = holoRef ?: r.copyOf().also { holoRef = it }
            // H = B · (Rᵀ·R0) · B : undoes the phone's rotation since the reference pose
            val h = FloatArray(9)
            for (i in 0..2) for (j in 0..2) {
                var d = 0f
                for (k in 0..2) d += r[k * 3 + i] * ref[k * 3 + j]
                h[i * 3 + j] = d * b[i] * b[j]
            }
            render.post { engine.setHologram(h) }
        }
        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
    }

    private fun startHologram() {
        val sm = getSystemService(SensorManager::class.java) ?: return
        val sensor = sm.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR)
            ?: sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR) ?: return
        holoRef = null
        sm.registerListener(holoListener, sensor, SensorManager.SENSOR_DELAY_GAME)
    }

    private fun stopHologram() {
        getSystemService(SensorManager::class.java)?.unregisterListener(holoListener)
        render.post { engine.setHologram(null) }
    }

    private var batteryRegistered = false
    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            val lvl = i?.let { Reactive.levelIfCharging(it) } ?: -1f
            render.post { engine.fill = lvl }
        }
    }

    private fun startBattery() {
        if (batteryRegistered) return
        registerReceiver(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED), Context.RECEIVER_NOT_EXPORTED)
        batteryRegistered = true
    }

    private fun stopBattery() {
        if (batteryRegistered) { try { unregisterReceiver(batteryReceiver) } catch (_: Throwable) { } }
        batteryRegistered = false
        render.post { engine.fill = -1f }
    }

    private var beat: BeatDetector? = null

    private fun hasMic() = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun startBeat() {
        if (beat != null) return
        if (!hasMic()) { musicStatus = "Needs the audio permission"; return }
        val d = BeatDetector { level, hit ->
            val amt = settings.beatAmount
            render.post {
                engine.spinBoost = 1f + 3f * amt * level
                if (hit) engine.kick(0.25f + 0.6f * amt)
            }
        }
        val err = d.start()
        if (err == null) { beat = d; musicStatus = "Listening to what's playing" }
        else musicStatus = "Audio not available: $err"
    }

    private fun stopBeat() {
        beat?.stop()
        beat = null
        musicStatus = ""
        render.post { engine.spinBoost = 1f }
    }

    fun snapshot(dst: FloatArray) {
        synchronized(lock) { System.arraycopy(snapshot, 0, dst, 0, min(dst.size, snapshot.size)) }
    }

    fun drag(dYaw: Float, dPitch: Float, dt: Float) = render.post { engine.drag(dYaw, dPitch, dt) }
    fun release() = render.post { engine.release() }
    fun nextShape() = render.post { engine.nextShape() }
    fun previousShape() = render.post { engine.previousShape() }
    fun selectShape(id: String) = render.post { engine.select(id) }

    fun leaveForeground() {
        if (foreground) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            foreground = false
        }
        releaseWake()
        stopSelf()      // still alive while the activity is bound
    }

    // ------------------------------------------------------------------ internals

    private fun requestPowerOn() {
        pendingSince = SystemClock.uptimeMillis()
        pendingPowerOn = true
    }

    /** CRT power-off on the LEDs, then let go of the matrix once it's dark. */
    private fun powerDown() {
        pendingPowerOn = false
        render.post { engine.power(false) }
        main.removeCallbacks(releaseIfOff)
        main.postDelayed(releaseIfOff, 1000L)
    }

    private fun stopPlayback() {
        pendingPowerOn = false
        render.post { engine.power(false) }
        setStatus("Stopped")
        main.postDelayed({
            releaseGlyph()
            if (!uiAttached) leaveForeground()
        }, 1000L)
    }

    private fun ensureGlyph() {
        if (!settings.mirror) { setStatus(idleText()); return }
        if (glyph == null) glyph = GlyphLink(this) { setStatus(it) }
        glyph?.connect()
    }

    private fun releaseGlyph() {
        glyph?.release()
        glyph = null
        setStatus(idleText())
    }

    private fun idleText() =
        if (Device.hasMatrix) "Glyph Matrix off" else "No Glyph Matrix on this device: preview only"

    private fun setStatus(s: String) {
        lastStatus = s
        statusListener?.invoke(s)
    }

    private fun enterForeground(force: Boolean = false) {
        if (foreground && !force) return
        var type = ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        if (settings.beatSync && hasMic()) type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        try {
            startForeground(NOTIF_ID, buildNotification(), type)
        } catch (_: Throwable) {
            startForeground(NOTIF_ID, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        }
        foreground = true
    }

    private fun acquireWake() {
        if (wakeLock?.isHeld == true) return
        val pm = getSystemService(PowerManager::class.java) ?: return
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "phosphore:playback").apply {
            setReferenceCounted(false)
            val mins = settings.sleepMinutes
            acquire(if (mins > 0) mins * 60_000L + 5_000L else 6 * 60 * 60_000L)
        }
    }

    private fun releaseWake() {
        try { wakeLock?.let { if (it.isHeld) it.release() } } catch (_: Throwable) { }
        wakeLock = null
    }

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java) ?: return
        nm.createNotificationChannel(NotificationChannel(
            CHANNEL, "Playback", NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Shown while Phosphore keeps the Glyph Matrix running"
            setShowBadge(false)
        })
    }

    private fun refreshNotification() {
        if (!foreground) return
        getSystemService(NotificationManager::class.java)?.notify(NOTIF_ID, buildNotification())
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        fun action(act: String, req: Int) = PendingIntent.getService(
            this, req, Intent(this, PlayerService::class.java).setAction(act),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val name = library.byId(currentShapeId)?.name ?: "Phosphore"
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(name)
            .setContentText("Playing on the Glyph Matrix")
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(Notification.CATEGORY_SERVICE)
            .addAction(Notification.Action.Builder(null as Icon?, "Next trace", action(ACTION_NEXT, 1)).build())
            .addAction(Notification.Action.Builder(null as Icon?, "Stop", action(ACTION_STOP, 2)).build())
            .build()
    }

    companion object {
        const val ACTION_PLAY = "com.adrienby.phosphore.PLAY"
        const val ACTION_NEXT = "com.adrienby.phosphore.NEXT"
        const val ACTION_STOP = "com.adrienby.phosphore.STOP"
        const val STATE_OFF = 0
        const val STATE_NONE = 1
        const val STATE_CONNECTING = 2
        const val STATE_LIVE = 3
        private const val CHANNEL = "playback"
        private const val NOTIF_ID = 1
    }
}
