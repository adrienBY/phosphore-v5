package com.adrienby.phosphore

import com.nothing.ketchum.Common
import com.nothing.ketchum.Glyph

object Device {
    /** 13 on Phone (4a) Pro, 25 on Phone (3). Falls back to 13 elsewhere so the preview still runs. */
    val matrixLength: Int by lazy {
        try {
            Common.getDeviceMatrixLength().takeIf { it == 13 || it == 25 } ?: 13
        } catch (_: Throwable) { 13 }
    }

    val hasMatrix: Boolean by lazy {
        try { Common.is25111p() || Common.is23112() } catch (_: Throwable) { false }
    }

    val target: String
        get() = if (matrixLength == 25) Glyph.DEVICE_23112 else Glyph.DEVICE_25111p

    val label: String
        get() = if (matrixLength == 25) "Phone (3)" else "Phone (4a) Pro"
}
