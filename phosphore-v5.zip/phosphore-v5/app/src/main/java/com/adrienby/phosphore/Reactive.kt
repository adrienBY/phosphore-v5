package com.adrienby.phosphore

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.SystemClock
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** In-process hand-off from the notification listener to the player. */
object Reactive {
    @Volatile var onNotification: (() -> Unit)? = null

    /** Battery level 0..1 while plugged in, null otherwise. */
    fun chargingLevel(ctx: Context): Float? {
        val i: Intent = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return null
        return levelIfCharging(i)
    }

    fun levelIfCharging(i: Intent): Float? {
        val st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
        if (!charging) return null
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        if (level < 0 || scale <= 0) return null
        return (level.toFloat() / scale).coerceIn(0f, 1f)
    }
}

/** Needs "Notification access" granted in Settings; only reports that something arrived. */
class NotifListener : NotificationListenerService() {
    private val lastByKey = HashMap<String, Long>()
    private var lastAny = 0L

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName || sbn.isOngoing) return
        val n = sbn.notification
        if (n.flags and android.app.Notification.FLAG_GROUP_SUMMARY != 0) return
        val now = SystemClock.uptimeMillis()
        val prev = lastByKey[sbn.key]
        lastByKey[sbn.key] = now
        if (prev != null && now - prev < 4000) return          // progress updates, edits
        if (now - lastAny < 600) return
        lastAny = now
        if (lastByKey.size > 200) lastByKey.clear()
        Reactive.onNotification?.invoke()
    }
}
