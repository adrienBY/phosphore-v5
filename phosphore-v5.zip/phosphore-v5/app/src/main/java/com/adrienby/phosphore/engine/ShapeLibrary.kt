package com.adrienby.phosphore.engine

import java.io.File

/** Built-in shapes plus the user's own (drawn or imported), read from [customDir]. */
class ShapeLibrary(private val customDir: File?) {

    @Volatile var shapes: List<Shape> = build()
        private set

    fun reload() { shapes = build() }

    fun byId(id: String): Shape? = shapes.firstOrNull { it.id == id }

    private fun build(): List<Shape> =
        Shapes.all + (customDir?.let { CustomShapes.list(it) } ?: emptyList())
}
