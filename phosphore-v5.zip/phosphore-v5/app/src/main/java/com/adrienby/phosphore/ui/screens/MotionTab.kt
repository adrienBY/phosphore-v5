package com.adrienby.phosphore.ui.screens

import androidx.compose.runtime.Composable
import com.adrienby.phosphore.engine.ScopeSettings.Companion as K
import com.adrienby.phosphore.ui.AppViewModel
import com.adrienby.phosphore.ui.Haptics
import com.adrienby.phosphore.ui.components.ChipButton
import com.adrienby.phosphore.ui.components.ChipRow
import com.adrienby.phosphore.ui.components.Fader
import com.adrienby.phosphore.ui.components.Note
import com.adrienby.phosphore.ui.components.SectionCard
import com.adrienby.phosphore.ui.components.ToggleRow
import kotlin.math.roundToInt

@Composable
fun MotionTab(vm: AppViewModel) = TabPage {
    val s = vm.settings
    val d = vm.defaults

    SectionCard("Spin") {
        Options(null, listOf("Tumble" to K.SPIN_TUMBLE, "Turntable" to K.SPIN_TURNTABLE, "Still" to K.SPIN_STILL), s.spinMode) { v ->
            vm.change { it.copy(spinMode = v) }
        }
        Fader("Rotation speed", s.rotation, d.rotation, { "%.1f rpm".format(K.rotationRadPerSec(it) * 60f / 6.2832f) }) { v ->
            vm.change { it.copy(rotation = v) }
        }
        Fader("Size", s.size, d.size, { "%d%%".format((K.sizeMul(it) * 100).roundToInt()) }) { v -> vm.change { it.copy(size = v) } }
        Note("Drag the preview to spin the trace by hand; it keeps a little momentum.")
    }

    SectionCard("Steady hologram",
        "The trace stays fixed in space while you turn the phone, as if it floated behind the glass. Best with Spin: Still.") {
        ToggleRow("Steady hologram", null, s.hologram) { on -> vm.change { it.copy(hologram = on) } }
        ChipRow { ChipButton("Recenter") { vm.player?.recenterHologram(); Haptics.confirm() } }
    }
}
