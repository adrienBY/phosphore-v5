package com.adrienby.phosphore.ui.screens

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import com.adrienby.phosphore.Device
import com.adrienby.phosphore.ui.AppViewModel
import com.adrienby.phosphore.ui.components.Fader
import com.adrienby.phosphore.ui.components.GhostButton
import com.adrienby.phosphore.ui.components.Note
import com.adrienby.phosphore.ui.components.PrimaryButton
import com.adrienby.phosphore.ui.components.SectionCard
import com.adrienby.phosphore.ui.components.ToggleRow
import com.adrienby.phosphore.ui.theme.Ph
import androidx.compose.material3.Text
import com.adrienby.phosphore.ui.theme.PhType
import androidx.compose.foundation.layout.padding
import androidx.compose.ui.unit.dp

@Composable
fun OutputTab(vm: AppViewModel, onToySettings: () -> Unit, onBackgroundOn: () -> Unit) = TabPage {
    val s = vm.settings
    val d = vm.defaults

    SectionCard("Glyph Matrix") {
        ToggleRow("Show on the back of the phone", null, s.mirror) { on -> vm.change { it.copy(mirror = on) } }
        ToggleRow("Keep playing after you leave the app", null, s.background) { on ->
            vm.change { it.copy(background = on) }
            if (on) onBackgroundOn()
        }
        ToggleRow("Keep playing with the screen off", "Keeps the processor awake until the timer below runs out.", s.screenOff) { on ->
            vm.change { it.copy(screenOff = on) }
        }
        Options("Stop after leaving the app", listOf("15 min" to 15, "30 min" to 30, "1 h" to 60, "3 h" to 180, "Never" to 0), s.sleepMinutes) { v ->
            vm.change { it.copy(sleepMinutes = v) }
        }
        Fader("LED brightness", s.brightness, d.brightness, ::pct) { v -> vm.change { it.copy(brightness = v) } }
        Options("Frame rate", listOf("15 fps" to 15, "30 fps" to 30, "60 fps" to 60), s.matrixFps) { v -> vm.change { it.copy(matrixFps = v) } }
    }

    SectionCard("Orientation") {
        Options("Rotate", listOf("0°" to 0, "90°" to 90, "180°" to 180, "270°" to 270), s.rotate) { v -> vm.change { it.copy(rotate = v) } }
        ToggleRow("Mirror horizontally", null, s.flipX) { on -> vm.change { it.copy(flipX = on) } }
        ToggleRow("Invert", "Dark trace on a lit disc", s.invert) { on -> vm.change { it.copy(invert = on) } }
    }

    SectionCard("Always-on Glyph Toy") {
        Options("Run time each time it starts", listOf("1 min" to 1, "5 min" to 5, "15 min" to 15, "No limit" to 0), s.aodMinutes) { v ->
            vm.change { it.copy(aodMinutes = v) }
        }
        PrimaryButton("Use as Always-on Glyph Toy", onToySettings)
        Note(
            if (vm.n == 13) "Settings › Glyph Interface › Flip to Glyph › Always-on Glyph Toy, then pick Phosphore. It plays your current settings whenever the phone lies face down."
            else "Add Phosphore to your Glyph Toys. A long press on the Glyph Button switches trace."
        )
    }

    SectionCard("App") {
        ToggleRow("Haptics", "Textured sliders, clicks and thuds", s.haptics) { on -> vm.change { it.copy(haptics = on) } }
        GhostButton("Reset everything to defaults", Ph.Danger) { vm.resetAll() }
        Text(
            "Phosphore 5.0 · ${Device.label} · ${vm.n}×${vm.n}", style = PhType.note, color = Ph.InkFaint, textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth().padding(top = 14.dp),
        )
    }
}
