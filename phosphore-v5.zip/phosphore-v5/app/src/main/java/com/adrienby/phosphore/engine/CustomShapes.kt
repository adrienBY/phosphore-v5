package com.adrienby.phosphore.engine

import java.io.File
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt

/** A shape the user drew or imported. Stored normalised; the file keeps the raw strokes. */
class CustomShape(
    override val id: String,
    override val name: String,
    private val data: List<FloatArray>,
) : Shape {
    override val category = Shapes.CUSTOM
    override fun strokes(t: Float) = data
}

/**
 * Plain-text trace files in the app's private storage:
 *
 *     name=My lathe
 *     s x y z x y z ...      (one stroke per line)
 */
object CustomShapes {

    private const val EXT = ".trace"

    fun list(dir: File): List<Shape> =
        (dir.listFiles { f -> f.name.endsWith(EXT) } ?: emptyArray())
            .sortedBy { it.lastModified() }
            .mapNotNull { load(it) }

    fun load(f: File): Shape? = try {
        var name = f.nameWithoutExtension
        val strokes = ArrayList<FloatArray>()
        f.forEachLine { line ->
            when {
                line.startsWith("name=") -> name = line.substring(5).trim().ifEmpty { name }
                line.startsWith("s ") -> {
                    val nums = line.substring(2).trim().split(' ').mapNotNull { it.toFloatOrNull() }
                    if (nums.size >= 6 && nums.size % 3 == 0) strokes.add(nums.toFloatArray())
                }
            }
        }
        if (strokes.isEmpty()) null else CustomShape(idFor(f), name, Shapes.normalize(strokes))
    } catch (_: Throwable) { null }

    fun save(dir: File, name: String, strokes: List<FloatArray>): String {
        dir.mkdirs()
        val f = File(dir, "c${System.currentTimeMillis()}$EXT")
        f.bufferedWriter().use { w ->
            w.write("name=${name.replace('\n', ' ')}\n")
            for (s in strokes) {
                w.write("s")
                for (v in s) { w.write(" "); w.write("%.4f".format(java.util.Locale.ROOT, v)) }
                w.write("\n")
            }
        }
        return idFor(f)
    }

    fun delete(dir: File, id: String) {
        if (!id.startsWith("custom:")) return
        File(dir, id.removePrefix("custom:")).delete()
    }

    private fun idFor(f: File) = "custom:${f.name}"

    // ================================================================== OBJ import

    class ImportResult(val strokes: List<FloatArray>, val edgeCount: Int, val note: String)

    /**
     * Wavefront OBJ -> wireframe. Vertices are welded by position (UV seams would otherwise
     * show up as edges), then only "feature" edges are kept: boundaries and creases sharper
     * than ~25°. That keeps a low-poly model's real edges and turns smooth meshes into
     * readable outlines instead of a solid blob of 13×13 LEDs.
     */
    fun importObj(text: String, maxEdges: Int = 400): ImportResult {
        val rawV = ArrayList<FloatArray>()
        val faces = ArrayList<IntArray>()
        val lines = ArrayList<IntArray>()
        fun idx(tok: String, count: Int): Int? {
            val i = tok.substringBefore('/').toIntOrNull() ?: return null
            return if (i < 0) count + i else i - 1
        }
        text.lineSequence().forEach { raw ->
            val l = raw.trim()
            when {
                l.startsWith("v ") -> {
                    val p = l.substring(2).trim().split(Regex("\\s+")).mapNotNull { it.toFloatOrNull() }
                    if (p.size >= 3) rawV.add(floatArrayOf(p[0], p[1], p[2]))
                }
                l.startsWith("f ") -> {
                    val ids = l.substring(2).trim().split(Regex("\\s+")).mapNotNull { idx(it, rawV.size) }
                    if (ids.size >= 3) faces.add(ids.toIntArray())
                }
                l.startsWith("l ") -> {
                    val ids = l.substring(2).trim().split(Regex("\\s+")).mapNotNull { idx(it, rawV.size) }
                    if (ids.size >= 2) lines.add(ids.toIntArray())
                }
            }
        }
        require(rawV.size >= 2) { "No vertices found in this file" }

        // weld by quantised position
        var lo = floatArrayOf(Float.MAX_VALUE, Float.MAX_VALUE, Float.MAX_VALUE)
        var hi = floatArrayOf(-Float.MAX_VALUE, -Float.MAX_VALUE, -Float.MAX_VALUE)
        for (v in rawV) for (k in 0..2) { lo[k] = minOf(lo[k], v[k]); hi[k] = maxOf(hi[k], v[k]) }
        val q = max(max(hi[0] - lo[0], hi[1] - lo[1]), hi[2] - lo[2]).coerceAtLeast(1e-6f) * 1e-4f
        val weld = IntArray(rawV.size)
        val verts = ArrayList<FloatArray>()
        val seen = HashMap<Triple<Long, Long, Long>, Int>()
        rawV.forEachIndexed { i, v ->
            val key = Triple((v[0] / q).toLong(), (v[1] / q).toLong(), (v[2] / q).toLong())
            weld[i] = seen.getOrPut(key) { verts.add(v); verts.size - 1 }
        }
        fun w(i: Int) = if (i in weld.indices) weld[i] else -1

        // edges -> adjacent face normals
        val edgeFaces = HashMap<Long, MutableList<Int>>()
        val normals = ArrayList<FloatArray>()
        fun key(a: Int, b: Int) = if (a < b) a.toLong() shl 32 or b.toLong() else b.toLong() shl 32 or a.toLong()
        for (f in faces) {
            val ids = f.map { w(it) }.filter { it >= 0 }
            if (ids.size < 3) continue
            val n = newell(ids.map { verts[it] })
            val fi = normals.size
            normals.add(n)
            for (k in ids.indices) {
                val a = ids[k]; val b = ids[(k + 1) % ids.size]
                if (a != b) edgeFaces.getOrPut(key(a, b)) { ArrayList() }.add(fi)
            }
        }
        val keep = LinkedHashSet<Long>()
        val cosCrease = cos(25.0 * PI / 180.0).toFloat()
        for ((k, fs) in edgeFaces) {
            if (fs.size != 2) { keep.add(k); continue }
            val a = normals[fs[0]]; val b = normals[fs[1]]
            if (a[0] * b[0] + a[1] * b[1] + a[2] * b[2] < cosCrease) keep.add(k)
        }
        for (l in lines) for (k in 0 until l.size - 1) {
            val a = w(l[k]); val b = w(l[k + 1])
            if (a >= 0 && b >= 0 && a != b) keep.add(key(a, b))
        }
        var note = "${keep.size} feature edges"
        if (keep.isEmpty()) {          // perfectly smooth model: fall back to every edge
            keep.addAll(edgeFaces.keys)
            note = "smooth model, using all ${keep.size} edges"
        }
        var edges = keep.map { intArrayOf((it shr 32).toInt(), (it and 0xffffffffL).toInt()) }
        if (edges.size > maxEdges) {
            edges = edges.sortedByDescending { len(verts[it[0]], verts[it[1]]) }.take(maxEdges)
            note = "kept the $maxEdges longest of ${keep.size} edges"
        }
        require(edges.isNotEmpty()) { "No edges found in this file" }

        val paths = Shapes.chainEdges(verts.size, edges)
        val strokes = paths.map { p -> FloatArray(p.size * 3) { verts[p[it / 3]][it % 3] } }
        return ImportResult(strokes, edges.size, note)
    }

    private fun newell(p: List<FloatArray>): FloatArray {
        var nx = 0f; var ny = 0f; var nz = 0f
        for (i in p.indices) {
            val a = p[i]; val b = p[(i + 1) % p.size]
            nx += (a[1] - b[1]) * (a[2] + b[2])
            ny += (a[2] - b[2]) * (a[0] + b[0])
            nz += (a[0] - b[0]) * (a[1] + b[1])
        }
        val l = sqrt(nx * nx + ny * ny + nz * nz).coerceAtLeast(1e-12f)
        return floatArrayOf(nx / l, ny / l, nz / l)
    }

    private fun len(a: FloatArray, b: FloatArray): Float {
        val dx = a[0] - b[0]; val dy = a[1] - b[1]; val dz = a[2] - b[2]
        return sqrt(dx * dx + dy * dy + dz * dz)
    }

    // ================================================================== drawings

    const val FLAT = 0
    const val EXTRUDE = 1
    const val LATHE = 2

    /** [strokes2d]: x,y pairs in -1..1 (y up). Returns 3D strokes for the chosen build mode. */
    fun fromDrawing(strokes2d: List<FloatArray>, mode: Int): List<FloatArray> {
        val src = strokes2d.filter { it.size >= 4 }
        return when (mode) {
            EXTRUDE -> {
                val out = ArrayList<FloatArray>()
                val d = 0.32f
                for (s in src) {
                    val n = s.size / 2
                    out.add(FloatArray(n * 3) { i -> when (i % 3) { 0 -> s[i / 3 * 2]; 1 -> s[i / 3 * 2 + 1]; else -> d } })
                    out.add(FloatArray(n * 3) { i -> when (i % 3) { 0 -> s[i / 3 * 2]; 1 -> s[i / 3 * 2 + 1]; else -> -d } })
                    val step = max(1, n / 6)
                    var k = 0
                    while (k < n) {
                        val x = s[k * 2]; val y = s[k * 2 + 1]
                        out.add(floatArrayOf(x, y, d, x, y, -d))
                        k = if (k == n - 1) n else minOf(n - 1, k + step)
                    }
                }
                out
            }
            LATHE -> {
                val out = ArrayList<FloatArray>()
                val meridians = 8
                for (s in src) {
                    val n = s.size / 2
                    for (m in 0 until meridians) {
                        val a = (2.0 * PI * m / meridians).toFloat()
                        val c = cos(a); val sn = sin(a)
                        out.add(FloatArray(n * 3) { i ->
                            val r = abs(s[i / 3 * 2]); val y = s[i / 3 * 2 + 1]
                            when (i % 3) { 0 -> r * c; 1 -> y; else -> r * sn }
                        })
                    }
                    for (j in 0 until 4) {
                        val k = ((n - 1) * j / 3f).toInt()
                        val r = abs(s[k * 2]); val y = s[k * 2 + 1]
                        if (r < 0.03f) continue
                        out.add(FloatArray(41 * 3) { i ->
                            val a = (2.0 * PI * (i / 3) / 40).toFloat()
                            when (i % 3) { 0 -> r * cos(a); 1 -> y; else -> r * sin(a) }
                        })
                    }
                }
                out
            }
            else -> src.map { s -> FloatArray(s.size / 2 * 3) { i -> when (i % 3) { 0 -> s[i / 3 * 2]; 1 -> s[i / 3 * 2 + 1]; else -> 0f } } }
        }
    }
}
