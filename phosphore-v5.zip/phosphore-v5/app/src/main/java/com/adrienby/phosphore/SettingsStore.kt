package com.adrienby.phosphore

import android.content.Context
import com.adrienby.phosphore.engine.ScopeSettings
import com.adrienby.phosphore.engine.Shapes
import java.io.File
import java.util.Properties
import java.util.concurrent.Executors

/**
 * Plain properties file instead of SharedPreferences: the Always-on toy runs in its own
 * process (":toy") and SharedPreferences caches per process.
 */
object SettingsStore {
    private const val NAME = "scope.properties"
    private val io = Executors.newSingleThreadExecutor()

    fun load(ctx: Context): ScopeSettings {
        val f = File(ctx.filesDir, NAME)
        if (!f.exists()) return ScopeSettings()
        val p = Properties()
        return try {
            f.inputStream().use { p.load(it) }
            val d = ScopeSettings()
            fun fl(k: String, def: Float) = p.getProperty(k)?.toFloatOrNull()?.coerceIn(0f, 1f) ?: def
            fun i(k: String, def: Int) = p.getProperty(k)?.toIntOrNull() ?: def
            fun b(k: String, def: Boolean) = p.getProperty(k)?.toBooleanStrictOrNull() ?: def
            ScopeSettings(
                shapeId = p.getProperty("shapeId")
                    ?: p.getProperty("shape")?.toIntOrNull()?.let { Shapes.all.getOrNull(it)?.id }  // v1/v2 index
                    ?: d.shapeId,
                autoCycle = i("autoCycle", d.autoCycle),
                shuffle = b("shuffle", d.shuffle),
                morphMs = i("morphMs", d.morphMs),
                hologram = b("hologram", d.hologram),
                notifPulse = b("notifPulse", d.notifPulse),
                batteryFill = b("batteryFill", d.batteryFill),
                beatSync = b("beatSync", d.beatSync),
                beatAmount = fl("beatAmount", d.beatAmount),
                spinMode = i("spinMode", d.spinMode).coerceIn(0, 2),
                rotation = fl("rotation", d.rotation),
                size = fl("size", d.size),
                sweep = fl("sweep", d.sweep),
                sweepLfo = b("sweepLfo", d.sweepLfo),
                lfoShape = i("lfoShape", d.lfoShape).coerceIn(0, 3),
                lfoRate = fl("lfoRate", d.lfoRate),
                lfoDepth = fl("lfoDepth", d.lfoDepth),
                haptics = b("haptics", d.haptics),
                tab = i("tab", d.tab).coerceIn(0, 4),
                bandwidth = fl("bandwidth", d.bandwidth),
                focus = fl("focus", d.focus),
                persistence = fl("persistence", d.persistence),
                intensity = fl("intensity", d.intensity),
                contrast = fl("contrast", d.contrast),
                depth = fl("depth", d.depth),
                noise = fl("noise", d.noise),
                breathing = fl("breathing", d.breathing),
                mirror = b("mirror", d.mirror),
                background = b("background", d.background),
                screenOff = b("screenOff", d.screenOff),
                sleepMinutes = i("sleepMinutes", d.sleepMinutes),
                matrixFps = i("matrixFps", d.matrixFps).coerceIn(5, 60),
                brightness = fl("brightness", d.brightness),
                invert = b("invert", d.invert),
                flipX = b("flipX", d.flipX),
                rotate = i("rotate", d.rotate).let { if (it in listOf(0, 90, 180, 270)) it else 0 },
                aodMinutes = i("aodMinutes", d.aodMinutes),
            )
        } catch (_: Throwable) {
            ScopeSettings()
        }
    }

    /** Off the main thread; writes are serialised so the last one always wins. */
    fun saveAsync(ctx: Context, s: ScopeSettings) {
        val app = ctx.applicationContext
        io.execute { save(app, s) }
    }

    @Synchronized
    fun save(ctx: Context, s: ScopeSettings) {
        val p = Properties()
        fun put(k: String, v: Any) { p.setProperty(k, v.toString()) }
        put("shapeId", s.shapeId); put("autoCycle", s.autoCycle); put("shuffle", s.shuffle)
        put("morphMs", s.morphMs); put("hologram", s.hologram); put("notifPulse", s.notifPulse)
        put("batteryFill", s.batteryFill); put("beatSync", s.beatSync); put("beatAmount", s.beatAmount)
        put("spinMode", s.spinMode); put("rotation", s.rotation); put("size", s.size)
        put("sweep", s.sweep); put("bandwidth", s.bandwidth); put("focus", s.focus)
        put("sweepLfo", s.sweepLfo); put("lfoShape", s.lfoShape); put("lfoRate", s.lfoRate)
        put("lfoDepth", s.lfoDepth); put("haptics", s.haptics); put("tab", s.tab)
        put("persistence", s.persistence); put("intensity", s.intensity); put("contrast", s.contrast)
        put("depth", s.depth); put("noise", s.noise); put("breathing", s.breathing)
        put("mirror", s.mirror); put("background", s.background); put("screenOff", s.screenOff)
        put("sleepMinutes", s.sleepMinutes); put("matrixFps", s.matrixFps); put("brightness", s.brightness)
        put("invert", s.invert); put("flipX", s.flipX); put("rotate", s.rotate)
        put("aodMinutes", s.aodMinutes)
        try {
            val target = File(ctx.filesDir, NAME)
            val tmp = File(ctx.filesDir, "$NAME.tmp")
            tmp.outputStream().use { p.store(it, null) }
            if (!tmp.renameTo(target)) {
                target.delete()
                if (!tmp.renameTo(target)) target.outputStream().use { p.store(it, null) }
            }
        } catch (_: Throwable) { }
    }

    /** Where drawn / imported traces live (shared by the player and the toy process). */
    fun shapesDir(ctx: Context) = File(ctx.filesDir, "shapes")

    /** Lets the toy process notice edits made in the app while it's already running. */
    fun stamp(ctx: Context): Long = File(ctx.filesDir, NAME).lastModified()
}
