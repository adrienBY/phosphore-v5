package com.adrienby.phosphore.ui

import android.content.Context
import android.os.SystemClock
import android.os.VibrationAttributes
import android.os.VibrationEffect
import android.os.VibrationEffect.Composition
import android.os.Vibrator
import android.os.VibratorManager

/**
 * Haptic vocabulary built from vibration primitives (low ticks, clicks, thuds, rises), tuned
 * for a wide-band motor like Nothing's. Falls back to predefined effects on motors without
 * primitive support. Uses the TOUCH vibration usage, so the system's touch-feedback setting and
 * intensity apply automatically; the app's own switch is [enabled].
 */
object Haptics {
    @Volatile var enabled = true

    private var vib: Vibrator? = null
    private var primitives = false
    private var lastTick = 0L
    private val touch = VibrationAttributes.createForUsage(VibrationAttributes.USAGE_TOUCH)

    fun init(ctx: Context) {
        val app = ctx.applicationContext
        vib = app.getSystemService(VibratorManager::class.java)?.defaultVibrator
        primitives = vib?.areAllPrimitivesSupported(
            Composition.PRIMITIVE_TICK, Composition.PRIMITIVE_LOW_TICK, Composition.PRIMITIVE_CLICK,
            Composition.PRIMITIVE_THUD, Composition.PRIMITIVE_QUICK_RISE, Composition.PRIMITIVE_QUICK_FALL,
            Composition.PRIMITIVE_SLOW_RISE,
        ) == true
    }

    /** Slider texture: a light low tick per step, a little firmer when moving fast. */
    fun tick(speed: Float = 0f) {
        val now = SystemClock.uptimeMillis()
        if (now - lastTick < 14) return
        lastTick = now
        play(VibrationEffect.EFFECT_TICK) { addPrimitive(Composition.PRIMITIVE_LOW_TICK, (0.32f + 0.4f * speed).coerceAtMost(0.8f)) }
    }

    /** Selection change in a picker or tab. */
    fun detent() = play(VibrationEffect.EFFECT_TICK) { addPrimitive(Composition.PRIMITIVE_CLICK, 0.45f) }

    /** Soft click when a slider settles on its default. */
    fun snap() = play(VibrationEffect.EFFECT_CLICK) {
        addPrimitive(Composition.PRIMITIVE_CLICK, 0.7f)
        addPrimitive(Composition.PRIMITIVE_LOW_TICK, 0.3f, 25)
    }

    /** Hitting either end of a slider. */
    fun edge() = play(VibrationEffect.EFFECT_HEAVY_CLICK) { addPrimitive(Composition.PRIMITIVE_THUD, 0.6f) }

    fun dragStart() = play(VibrationEffect.EFFECT_TICK) { addPrimitive(Composition.PRIMITIVE_TICK, 0.5f) }

    fun press() = play(VibrationEffect.EFFECT_CLICK) { addPrimitive(Composition.PRIMITIVE_CLICK, 0.5f) }

    fun toggle(on: Boolean) = play(VibrationEffect.EFFECT_CLICK) {
        if (on) { addPrimitive(Composition.PRIMITIVE_TICK, 0.4f); addPrimitive(Composition.PRIMITIVE_CLICK, 0.9f, 35) }
        else { addPrimitive(Composition.PRIMITIVE_CLICK, 0.65f); addPrimitive(Composition.PRIMITIVE_LOW_TICK, 0.35f, 35) }
    }

    fun confirm() = play(VibrationEffect.EFFECT_DOUBLE_CLICK) {
        addPrimitive(Composition.PRIMITIVE_CLICK, 0.55f)
        addPrimitive(Composition.PRIMITIVE_CLICK, 1f, 70)
    }

    fun reject() = play(VibrationEffect.EFFECT_DOUBLE_CLICK) {
        addPrimitive(Composition.PRIMITIVE_THUD, 0.55f)
        addPrimitive(Composition.PRIMITIVE_THUD, 0.5f, 100)
    }

    fun longPress() = play(VibrationEffect.EFFECT_HEAVY_CLICK) { addPrimitive(Composition.PRIMITIVE_THUD, 0.5f) }

    /** CRT power: a swelling hum that lands on a click, and the reverse. */
    fun powerOn() = play(VibrationEffect.EFFECT_HEAVY_CLICK) {
        addPrimitive(Composition.PRIMITIVE_SLOW_RISE, 0.45f)
        addPrimitive(Composition.PRIMITIVE_CLICK, 0.85f, 10)
    }

    fun powerOff() = play(VibrationEffect.EFFECT_CLICK) {
        addPrimitive(Composition.PRIMITIVE_QUICK_FALL, 0.6f)
        addPrimitive(Composition.PRIMITIVE_LOW_TICK, 0.4f, 60)
    }

    /** Spinning the preview by hand. */
    fun spin() {
        val now = SystemClock.uptimeMillis()
        if (now - lastTick < 30) return
        lastTick = now
        play(VibrationEffect.EFFECT_TICK) { addPrimitive(Composition.PRIMITIVE_LOW_TICK, 0.25f) }
    }

    private inline fun play(fallback: Int, build: Composition.() -> Unit) {
        if (!enabled) return
        val v = vib ?: return
        try {
            val effect = if (primitives) VibrationEffect.startComposition().apply(build).compose()
                         else VibrationEffect.createPredefined(fallback)
            v.vibrate(effect, touch)
        } catch (_: Throwable) { }
    }
}
