package com.adrienby.phosphore

import android.app.Service
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.Messenger
import android.os.SystemClock
import com.adrienby.phosphore.engine.ScopeEngine
import com.adrienby.phosphore.engine.ScopeSettings
import com.adrienby.phosphore.engine.ShapeLibrary
import com.nothing.ketchum.GlyphMatrixManager
import com.nothing.ketchum.GlyphToy

/**
 * Glyph Toy. On Phone (4a) Pro toys are AOD-only: the system sends EVENT_AOD about once a
 * minute while the toy is the selected Always-on Glyph Toy. The first event starts the
 * animation; it runs for the configured time, then the LEDs go dark until the screen is
 * turned on again (otherwise the per-minute events would keep it running forever).
 *
 * Runs in its own process (":toy") so its GlyphMatrixManager singleton never collides with
 * the one the activity uses for live mirroring.
 */
class ScopeToyService : Service() {

    private val main = Handler(Looper.getMainLooper())
    private var gm: GlyphMatrixManager? = null
    private var ready = false

    private var engine: ScopeEngine? = null
    private var frame = IntArray(0)
    private var scratch = FloatArray(0)
    private var settings = ScopeSettings()
    private var animating = false
    private var lastNs = 0L
    private var stopAt = Long.MAX_VALUE
    private var timedOut = false
    private var stopping = false
    private var darkSince = 0L
    private var settingsStamp = 0L
    private var lastCheck = 0L
    private var lastBattery = 0L

    private val screenOn = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) { timedOut = false }
    }

    private val messenger = Messenger(Handler(Looper.getMainLooper()) { msg ->
        if (msg.what == GlyphToy.MSG_GLYPH_TOY) {
            when (msg.data?.getString(GlyphToy.MSG_GLYPH_TOY_DATA)) {
                GlyphToy.EVENT_AOD -> onAod()
                GlyphToy.EVENT_CHANGE -> engine?.nextShape()
            }
            true
        } else false
    })

    private val tick = object : Runnable {
        override fun run() {
            val e = engine ?: return
            if (!animating) return
            val now = System.nanoTime()
            val dt = if (lastNs == 0L) 1f / settings.matrixFps else (now - lastNs) / 1e9f
            lastNs = now
            val up = SystemClock.uptimeMillis()
            if (up - lastCheck > 500L) {
                lastCheck = up
                val st = SettingsStore.stamp(this@ScopeToyService)
                if (st != settingsStamp) {
                    settingsStamp = st
                    settings = SettingsStore.load(this@ScopeToyService)
                    e.apply(settings)
                }
            }
            if (up - lastBattery > 5000L) {
                lastBattery = up
                e.fill = if (settings.batteryFill) Reactive.chargingLevel(this@ScopeToyService) ?: -1f else -1f
            }
            e.step(dt)
            e.toLed(frame, scratch)
            try { gm?.setMatrixFrame(frame) } catch (_: Throwable) { }
            if (!stopping && SystemClock.uptimeMillis() >= stopAt) {
                timedOut = true
                stopping = true
                e.power(false)                       // CRT power-off, then go dark
            }
            if (stopping) {
                if (!e.isDark) darkSince = 0L
                else if (darkSince == 0L) darkSince = SystemClock.uptimeMillis()
                else if (SystemClock.uptimeMillis() - darkSince > 350L) { stopAnimation(); return }
            }
            main.postDelayed(this, (1000L / settings.matrixFps).coerceAtLeast(10L))
        }
    }

    override fun onCreate() {
        super.onCreate()
        registerReceiver(screenOn, IntentFilter(Intent.ACTION_SCREEN_ON), Context.RECEIVER_NOT_EXPORTED)
    }

    override fun onDestroy() {
        try { unregisterReceiver(screenOn) } catch (_: Throwable) { }
        shutdown()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder {
        connect()
        return messenger.binder
    }

    override fun onUnbind(intent: Intent?): Boolean {
        shutdown()
        return false
    }

    private fun connect() {
        if (gm != null) return
        try {
            val m = GlyphMatrixManager.getInstance(applicationContext)
            gm = m
            m.init(object : GlyphMatrixManager.Callback {
                override fun onServiceConnected(name: ComponentName?) {
                    try {
                        m.register(Device.target)
                        ready = true
                        // Phone (3) shows toys straight away; Phone (4a) Pro waits for EVENT_AOD.
                        if (Device.matrixLength == 25) startAnimation()
                    } catch (_: Throwable) { ready = false }
                }
                override fun onServiceDisconnected(name: ComponentName?) {
                    ready = false
                    stopAnimation(blank = false)
                }
            })
        } catch (_: Throwable) {
            gm = null
        }
    }

    private fun onAod() {
        if (!ready || timedOut || animating) return
        startAnimation()
    }
    // (while animating, the tick re-reads the settings file whenever the app saves it)

    private fun startAnimation() {
        settingsStamp = SettingsStore.stamp(this)
        settings = SettingsStore.load(this)
        val n = Device.matrixLength
        engine = ScopeEngine(n, ShapeLibrary(SettingsStore.shapesDir(this))).also {
            it.apply(settings)
            it.power(false, instant = true)
            it.power(true)                           // CRT power-on each time it starts
        }
        stopping = false
        darkSince = 0L
        lastBattery = 0L
        frame = IntArray(n * n)
        scratch = FloatArray(n * n)
        stopAt = if (settings.aodMinutes <= 0) Long.MAX_VALUE
                 else SystemClock.uptimeMillis() + settings.aodMinutes * 60_000L
        lastNs = 0L
        animating = true
        main.removeCallbacks(tick)
        main.post(tick)
    }

    private fun stopAnimation(blank: Boolean = true) {
        animating = false
        main.removeCallbacks(tick)
        if (blank && ready) {
            try { gm?.setMatrixFrame(IntArray(frame.size.coerceAtLeast(1))) } catch (_: Throwable) { }
        }
    }

    private fun shutdown() {
        stopAnimation()
        val m = gm ?: return
        gm = null
        ready = false
        try { m.turnOff() } catch (_: Throwable) { }
        try { m.unInit() } catch (_: Throwable) { }
    }
}
