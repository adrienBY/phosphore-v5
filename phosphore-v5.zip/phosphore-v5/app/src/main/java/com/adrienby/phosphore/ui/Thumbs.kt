package com.adrienby.phosphore.ui

import android.os.Handler
import android.os.Looper
import com.adrienby.phosphore.engine.ScopeEngine
import com.adrienby.phosphore.engine.ScopeSettings
import com.adrienby.phosphore.engine.ShapeLibrary
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors

/** Renders a still frame of each trace once, off the main thread, for the shape tiles. */
object Thumbs {
    private val cache = ConcurrentHashMap<String, FloatArray>()
    private val exec = Executors.newSingleThreadExecutor { r ->
        Thread(r, "phosphore-thumbs").apply { priority = Thread.MIN_PRIORITY }
    }
    private val main = Handler(Looper.getMainLooper())

    /** A crisp, still look that reads well at tile size, independent of the user's settings. */
    private val look = ScopeSettings(
        spinMode = ScopeSettings.SPIN_STILL, rotation = 0f, size = 0.55f,
        sweep = 0.95f, bandwidth = 0.9f, focus = 0.08f, persistence = 0.5f,
        intensity = 0.62f, contrast = 0.45f, depth = 0.55f, noise = 0f, brightness = 1f, morphMs = 0,
    )

    fun render(library: ShapeLibrary, n: Int, ids: List<String>, onReady: (String, FloatArray) -> Unit) {
        exec.execute {
            for (id in ids) {
                val hit = cache[id]
                if (hit != null) { main.post { onReady(id, hit) }; continue }
                val lv = try {
                    val e = ScopeEngine(n, library)
                    e.apply(look.copy(shapeId = id))
                    repeat(24) { e.step(1f / 30f) }
                    FloatArray(n * n).also { e.levels(it) }
                } catch (_: Throwable) { continue }
                cache[id] = lv
                main.post { onReady(id, lv) }
            }
        }
    }
}
